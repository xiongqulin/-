/*
      ��ʱ�о������������˿����û�е�ǶȲ���һ�£�
	����ģ�������˻�����û���ˣ����Բ���һ��Ҫע�����Ƿ��Ħ����
*/
#include "Users.h"
#include "Control.h"
#include "cloud_sport.h"
#include "shoot_status.h"
//#include "shoot.h"

Key_t L_Bullet_amount;  //��¼��ǰ����
Key_t S_Bullet_amount;
Key_t F_Key;  //������׼ģʽ��������F������ƶ��ٶȽ���
Key_t G_Key; 
Key_t Mouse_L;//������
Key_t Mouse_R;//����Ҽ�
Key_t C_Key;  //�Զ���������
Key_t V_Key;  //�Զ�����С����




/**********************************************************************
  * @ ������  �� Control_OFF
  * @ ����˵���� �ر������������ڴ���BUGʱ�رճ���
	
  * @ ����    ��   
  * @ ����ֵ  �� ��
  ********************************************************************/
extern int16_t target_config;
extern int16_t target_IMUconfig;
extern int8_t sin_targe_config;
extern int Lock_Flag;
extern int speed_L,speed_R;

void Control_OFF(void)
{
	APP_Init();
	
	if(speed_L > 0)
		speed_L = 0;
	else
		speed_L += 20;
	
	if(speed_R < 0)
		speed_R = 0;
	else
		speed_R -= 20;
		
	fricMotor_setSpeed_M(speed_L,speed_R);
	fricMotor_setSpeed_S(1000,1000);
	target_config = 1;
	Lock_Flag = 0;
	target_IMUconfig = 1;
//	sin_targe_config = 1;
}

/**********************************************************************
  * @ ������  �� Control_DR
  * @ ����˵���� ң�������ƣ�ֻҪ���ڼ�¼
  * @ ����    ��   
  * @ ����ֵ  �� ��
  ********************************************************************/
int Small_Flag = 0;
int S_Check = 0;
int Large_Flag = 0;
int L_Check = 0;
int shootflag_2 = 0;
int shoot_time = 0;
//float Last_Speed_S = 0.0f,Last_Speed_L = 0.0f;
//float Err_Shoot_S = 0.0f,Err_Shoot_L = 0.0f;
int small_time = 0;
void Control_DR(void)
{
	if(dr16_data.rc.s_right == 1)
	{
		if(small_time >= 20)
		{
			small_time = 0;
			Small_Flag = 1;
		}
		else
		{
			small_time++;
			Small_Flag = 0;
		}
	}
	else if(dr16_data.rc.s_right == 3)
	{
		Small_Flag = 0;
		Large_Flag = 0;
		S_Check = 1;
		L_Check = 1;
	}
	else
	{
		Large_Flag = 0;
		if(L_Check)
		{
			Large_Flag = 1;
		  L_Check = 0;
		}
	}
	int16_t Chassi_Vx = dr16_data.rc.ch2 * 8;
	int16_t Chassi_Vy = dr16_data.rc.ch3 * 8;
	int16_t Cloud_Vx =  dr16_data.rc.ch0 * 0.5;
	int16_t Cloud_Vy =  dr16_data.rc.ch1 * 0.5; 	
  /*С����*/
	//С���䲦��
	



	//��������ת��
	if(S_Bullet_amount.Out_Key <= 12)
	{
		if(shoot_time >= 100)
		{
			shootflag_2 = 1;
			shoot_time = 0;
		}
		else
			shootflag_2 = 0;
		shoot_time++;
	    shoot_control_small_(shootflag_2);
	}
	
	/*����*/
	Control_Large_shoot(&L_Bullet_amount.Out_Key,Large_Flag);

	/*��̨*/
	//С����׷�������̨
	shoot_deal();
  shoot_control_small(Small_Flag);
	Small_Follow_Large_IMU(Cloud_Vx,Cloud_Vy);
  cloud_IMU_sport_L();
	cloud_Normal_sport_S();
	
	/*����*/
	Inject(&powerBufferPool_t);
	chassis_sport(Chassi_Vx,Chassi_Vy,0,1,0);
	
	
}


/**********************************************************************
  * @ ������  �� Control_PC
  * @ ����˵���� ���Կ��ƣ���Ҫ���ڱ���
  * @ ����    ��   
  * @ ����ֵ  �� ��
  ********************************************************************/


float Chassis_Vx,Chassis_Vy,Cloud_Vx,Cloud_Vy;
float Speed_U_X = 0.0f,Speed_U_Y = 0.0f;
float Speed_D_X = 0.0f,Speed_D_Y = 0.0f;
int PC_config = 1;
Direction_t W_Key,A_Key,S_Key,D_Key;
int16_t W,A,S,D;
int16_t Mouse_L_time = 0,Mouse_R_time = 0;
int16_t Mouse_L_Shoot = 0,Mouse_R_Shoot = 0;
int16_t Small_time = 0;
int16_t Mouse_R_Last = 0,Mouse_R_Err = 0,Mouse_L_Last = 0;
int Key_F;
float shoot_speed_L = 0.0f,shoot_speed_S = 0.0f,shoot_speed_L_Err = 0.0f,shoot_speed_S_Err = 0.0f;
float shoot_speed_L_Last = 0.0f,shoot_speed_S_Last = 0.0f;
int flag_shoot_2 = 0;
int Key_G;
void Control_PC(void)
{
	if(PC_config)
	{
		Key_Config(&F_Key);
		Key_Config(&G_Key);
		Key_Config(&C_Key);
		Key_Config(&V_Key);
		Key_direction_Config(&W_Key,2500,10,5500);
		Key_direction_Config(&A_Key,-2500,10,-5500);
		Key_direction_Config(&S_Key,-2500,10,-5500);
		Key_direction_Config(&D_Key,2500,10,5500);
		PC_config = 0;
	}
	
	Chassis_Vx = Key_direction(dr16_data.keyBoard.press_A,dr16_data.keyBoard.press_Shift,dr16_data.keyBoard.press_Ctrl,&A_Key)
	             + Key_direction(dr16_data.keyBoard.press_D,dr16_data.keyBoard.press_Shift,dr16_data.keyBoard.press_Ctrl,&D_Key);
	Chassis_Vy = Key_direction(dr16_data.keyBoard.press_W,dr16_data.keyBoard.press_Shift,dr16_data.keyBoard.press_Ctrl,&W_Key) 
	             + Key_direction(dr16_data.keyBoard.press_S,dr16_data.keyBoard.press_Shift,dr16_data.keyBoard.press_Ctrl,&S_Key);

	
	Key_F = Key_Check_Single(dr16_data.keyBoard.press_F,&F_Key);
	Key_F %= 2;
	Key_G = Key_Check_Single(dr16_data.keyBoard.press_G,&G_Key);
	Key_G %= 2;
	int Key_C = Key_Check_Single(dr16_data.keyBoard.press_C,&C_Key);
	Key_C %= 2;
	int Key_V = Key_Check_Single(dr16_data.keyBoard.press_V,&V_Key);
	Key_V %= 2;
	
	
	shoot_deal();
	int R_Mouse = Key_Check_Single(dr16_data.mouse.keyRight,&Mouse_R);
	Mouse_R_Err = R_Mouse - Mouse_R_Last;
	Mouse_R_Last = R_Mouse;
	
	if(Key_C)
	{
		C_Key.Out_Key = 0;
	  L_Bullet_amount.Out_Key--;
	}
	if(Key_V)
	{
		V_Key.Out_Key = 0;
	  S_Bullet_amount.Out_Key--;
	}
	

	
	Cloud_Vx = dr16_data.mouse.x * 0.5 ;
	Cloud_Vy = -dr16_data.mouse.y * 0.5;
    /*����*/
	if(dr16_data.keyBoard.press_Q)
		Cloud_Vx -= 12;
	if(dr16_data.keyBoard.press_E)
		Cloud_Vx += 12;
	Small_Follow_Large_IMU(Cloud_Vx,Cloud_Vy);
	cloud_IMU_sport_L();
	cloud_Normal_sport_S();
		
		chassis_sport(Chassis_Vx,Chassis_Vy,0,1,0);
	if(S_Bullet_amount.Out_Key <= 20)
	{
		Small_time++;
		if(Small_time >= 100)
		{
			shoot_control_small_(1);
			Small_time = 0;
		}
		else
			shoot_control_small_(0);
	}
		
	if(Key_F)
	{
		int L_Mouse = Key_Check_Single(dr16_data.mouse.keyLeft,&Mouse_L);
		Mouse_L_Shoot = L_Mouse - Mouse_L_Last;
		Mouse_L_Last = L_Mouse;
		
	}
	else
	{
		if(dr16_data.mouse.keyLeft)
		{
			if(Mouse_L_time >= 50)
			{
				Mouse_L_time = 0;
				Mouse_L_Shoot = 1;
			}
			else
			{
				Mouse_L_Shoot = 0;
				Mouse_L_time++;
			}
		}
		else
			Mouse_L_time = 0;
   }
	shoot_control_small(Mouse_L_Shoot);
	Control_Large_shoot(&L_Bullet_amount.Out_Key,Mouse_R_Err);
}

void Bullet_amount_check(void)
{
	int VolageCHeck_L = GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0);
	int VolagrCheck_S = GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_1);
  Key_CheckVolageCHeck(VolageCHeck_L,&L_Bullet_amount);
	Key_CheckVolageCHeck(VolagrCheck_S,&S_Bullet_amount);
}

void APP_Init(void)
{
	shoot_config();
	Chassis_Init();
	PowerBufferPoolInit();
	cloud_init();
}


