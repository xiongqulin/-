#include "shoot_status.h"
#include "Judege.h"
#include "shoot.h"

int Limt_heart_L = 150;     //ǹ����������
int Limt_heart_S = 240;     
int shoot_flag_s = 0;
int shoot_flag_l = 0;

void shoot_deal(void)
{
	if(ext_game_robot_state.robot_level == Two_Level)
	{
		Limt_heart_L = 250;
		Limt_heart_S = 360;
	}
	if(ext_game_robot_state.robot_level == Three_Level)
	{
		Limt_heart_L = 400;
		Limt_heart_S = 480;
	}
	if((ext_power_heat_data.shooter_heat0 + 50) < Limt_heart_S)
		shoot_flag_s = 1;
	else
		shoot_flag_s = 0;
	
	if((ext_power_heat_data.shooter_heat1 + 100) < Limt_heart_L)
		shoot_flag_l = 1;
	else
		shoot_flag_l = 0;
}



