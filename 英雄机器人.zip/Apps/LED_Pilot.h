#ifndef LED_PILOT_H
#define LED_PILOT_H


void LED_Check(void);
void LED_Twinkle(int count);

#endif



