#include "shoot.h"
#include "UserMath.h"

#include "DR16_Receiver.h"
#include "M3508s.h"
#include "pid.h"

shootGun_t Shooting;


shoot_t shoot[3];


void Shoot_Init(shoot_t *shoot,int16_t Speed_L,int16_t Speed_R,int16_t SpeedM_L,int16_t SpeedM_R,float Fire_Angle,int16_t Frequency)
{
	shoot->FireSpeed_L = Speed_L;
	shoot->FireSpeed_R = Speed_R;
	shoot->SpeedMax_L = SpeedM_L;
	shoot->SpeedMax_R = SpeedM_R;
	shoot->Fire_Angle  = Fire_Angle;
	shoot->Frequency   = Frequency;
	shoot->Frequency_count = 0;
	shoot->last_angle = 0;
	shoot->ShootConfig = 1;
	shoot->ShootFlag = 0;
	shoot->ShootTime = 0;
	shoot->Shoot_Fail = 0;
	shoot->TimeCount = 0;
}
void shoot_config(void)
{
  Large_shoot_PID_config();
	Shoot_Init(&shoot[0],1000,1000,1250,1250,36864.0f,50);
	Shoot_Init(&shoot[2],1000,1000,1000,1000,36864.0f,50);
	PositionPID_paraReset(&M2006s[0].pid_speed,0.8,0.0f,1.0f,8000,500);
	PositionPID_paraReset(&M2006s[0].pid_angle,0.06f,0.0f,0.015f,4000,500);
	PositionPID_paraReset(&M2006s[2].pid_speed,0.8,0.0f,1.0f,8000,500);
	PositionPID_paraReset(&M2006s[2].pid_angle,0.06f,0.0f,0.015f,4000,500);
}

void fricMotor_setSpeed_S(uint16_t Speed_R,uint16_t Speed_L){
	if(Speed_R < FRICMOTOR_SPEEDMIN) Speed_R = FRICMOTOR_SPEEDMIN;
	if(Speed_L > FRICMOTOR_SPEEDMAX) Speed_L = FRICMOTOR_SPEEDMAX;
	
	TIM_SetComparex[0](TIM12, Speed_R);
	TIM_SetComparex[1](TIM12, Speed_L);

}


void fricMotor_setSpeed_M(int16_t Speed_R,int16_t Speed_L)
{
	M3508s[4].outCurrent = Incremental_PID(&M3508s[4].Speed_pid,Speed_L,M3508s[4].realSpeed);
	M3508s[5].outCurrent = Incremental_PID(&M3508s[5].Speed_pid,Speed_R,M3508s[5].realSpeed);
}


/*
   shoot[0].ShootFlag  ��������־λ��ͨ��ǹ���������ж��Ƿ�������ʱ��������
   ��ʱ�������ж�
*/
int Lock_Flag = 1;
int Lock_Time = 0;
int Lock_Config = 1;
extern int Key_F;
extern int Key_G;
int Key_flag = 0;
extern int shoot_flag_s;
//extern int shoot_flag_l;
void  shoot_control_small(int shootflag)
{
		/*��Ħ����һ��������ʱ��*/
  if(shoot[0].ShootTime == 1000)
	{
		shoot[0].FireSpeed_L++;
		shoot[0].FireSpeed_R++;
		if(shoot[0].FireSpeed_L >= shoot[0].SpeedMax_L)
			shoot[0].FireSpeed_L = shoot[0].SpeedMax_L;
		if(shoot[0].FireSpeed_R >= shoot[0].SpeedMax_R)
			shoot[0].FireSpeed_R = shoot[0].SpeedMax_R;
		Key_flag = 1;
		Lock_Flag = 1;
		shoot[0].ShootTime++;
	}
	else
	{
		shoot[0].ShootTime++;
	}
//	/*ң�������߹رղ��̺�Ħ����*/
//	if(dr16_data.offLineFlag)
//	{
//		fricMotor_setSpeed_S(1000,1000);
//		shoot[0].Fire_Angle = 0;
//	}
//	else
//	{
	//}
	
	
	if(Key_F && Key_flag)
	{
		shoot[0].FireSpeed_R++;
		shoot[0].FireSpeed_L++;
		if(shoot[0].FireSpeed_R > 1350)
			shoot[0].FireSpeed_R = 1350;
		if(shoot[0].FireSpeed_L > 1350)
			shoot[0].FireSpeed_L = 1350;
	}
	else if(!Key_F && Key_flag)
	{
		if(shoot[0].FireSpeed_R < 1250)
			shoot[0].FireSpeed_R++;
		else if(shoot[0].FireSpeed_R > 1250)
			shoot[0].FireSpeed_R--;
		if(shoot[0].FireSpeed_L < 1250)
			shoot[0].FireSpeed_L++;
		else if(shoot[0].FireSpeed_L > 1250)
			shoot[0].FireSpeed_L--;
	}

	if(Key_G || dr16_data.rc.s_left == 1)
		fricMotor_setSpeed_S(shoot[0].FireSpeed_L,shoot[0].FireSpeed_R);
	else
		fricMotor_setSpeed_S(1000,1000);

	
	if(shoot[0].ShootConfig == 1)
	{
		M2006s[0].targetAngle = M2006s[0].realAngle;
		shoot[0].ShootConfig  = 0;
	}
	if(shootflag && Lock_Flag && shoot_flag_s)
	{
		M2006s[0].targetAngle += shoot[0].Fire_Angle;
	}
	/*��ֹ�ܷ�*/
//	if(M2006s[0].pid_angle.err >= 40955)
//		M2006s[0].targetAngle = M2006s[0].totalAngle;
		/*�����ж�*/
	if(Lock_Flag)
	{
		if(abs(M2006s[0].pid_angle.err > 8192) && abs(M2006s[0].realSpeed < 30))
			shoot[0].TimeCount ++;
		else
			shoot[0].TimeCount = 0;
	}
	if(shoot[0].TimeCount >= 100)
	{
		Lock_Flag = 0;
		if(Lock_Config)
		{
			//�������ӿ췴ת��Ӧ
			M2006s[0].targetAngle = M2006s[0].totalAngle;
	  	M2006s[0].targetAngle -= 2 * shoot[0].Fire_Angle;
			Lock_Config = 0;
		}
		/*��תʱ�䲹��*/
		if(Lock_Time >= 50)
		{
			Lock_Flag = 1;
			Lock_Config = 1;
			Lock_Time = 0;
		}
		Lock_Time ++;
			
	}

	float M2006_PIDout = Position_PID(&M2006s[0].pid_angle,M2006s[0].targetAngle,M2006s[0].totalAngle);
	M2006s[0].outCurrent  = Position_PID(&M2006s[0].pid_speed,M2006_PIDout,M2006s[0].realSpeed);
	shoot[0].last_angle = M2006s[0].targetAngle;
  if(abs(M2006s[0].turnCount) > 100)
	{
		M2006s[0].targetAngle -= (8192 * M2006s[0].turnCount);
		M2006s[0].turnCount = 0;
	}
}


int Lock_Flag_2 = 1;
int Lock_Time_2 = 0;
int Lock_Config_2 = 1;
void  shoot_control_small_(int shootflag)
{
	
//	/*ң�������߹رղ��̺�Ħ����*/
//	if(dr16_data.offLineFlag)
//	{
//		fricMotor_setSpeed_S(1000,1000);
//		shoot[0].Fire_Angle = 0;
//	}
//	else
//	{
//		fricMotor_setSpeed_S(shoot[0].FireSpeed_R,shoot[0].FireSpeed_L);
//		shoot[0].Fire_Angle = 36864.0f;
//	}

	
	if(shoot[2].ShootConfig == 1)
	{
		M2006s[2].targetAngle = M2006s[2].realAngle;
		shoot[2].ShootConfig  = 0;
	}
	if(shootflag && Lock_Flag_2)
	{
		M2006s[2].targetAngle += shoot[2].Fire_Angle;
	}
	/*��ֹ�ܷ�*/
//	if(M2006s[2].pid_angle.err >= 40955)
//		M2006s[2].targetAngle = M2006s[2].totalAngle;
		/*�����ж�*/
	if(Lock_Flag_2)
	{
		if(abs(M2006s[2].pid_angle.err > 8192) && abs(M2006s[2].realSpeed < 30))
			shoot[2].TimeCount ++;
		else
			shoot[2].TimeCount = 0;
	}
	if(shoot[2].TimeCount >= 100)
	{
		Lock_Flag_2 = 0;
		if(Lock_Config_2)
		{
			//�������ӿ췴ת��Ӧ
			M2006s[2].targetAngle = M2006s[2].totalAngle;
	  	M2006s[2].targetAngle -= 2 * shoot[2].Fire_Angle;
			Lock_Config_2 = 0;
		}
		/*��תʱ�䲹��*/
		if(Lock_Time_2 >= 50)
		{
			Lock_Flag_2 = 1;
			Lock_Config_2 = 1;
			Lock_Time_2 = 0;
		}
		Lock_Time_2 ++;
	}

	float M2006_PIDout_2 = Position_PID(&M2006s[2].pid_angle,M2006s[2].targetAngle,M2006s[2].totalAngle);
	M2006s[2].outCurrent  = Position_PID(&M2006s[2].pid_speed,M2006_PIDout_2,M2006s[2].realSpeed);
//  if(abs(M2006s[2].turnCount) > 100)
//	{
//		M2006s[2].targetAngle -= (8192 * M2006s[2].turnCount);
//		M2006s[2].turnCount = 0;
//	}
}



/**********************************************************************
  * @ ������  �� Large_Shoot
  * @ ����˵���� ���̴���
  * @ ����    �� *Bullet_amount��ǰ��������
  * @ ����ֵ  �� ��
  ********************************************************************/
int shoot_config_L = 1;        //��ʼ���������
int shoot_target_speed;        //�����ٶ�
int shoot_check_flag = 1;      //��������ʱֹͣ��������־λ
int check_time = 0;            //������ʱ
int deal_check_time = 0;       //����������ʱ
int out_speed = 0;             //����ٶ�

void Large_Shoot(int *Bullet_amount)
{
	if(shoot_config_L)
	{
		shoot_target_speed = 100;
	  shoot_config_L = 0;
	}
	if(abs(M3508s[6].Speed_pid.err) >= 70 && shoot_check_flag)
	{
		check_time++;
	}
	else if(abs(M3508s[1].Speed_pid.err) <= 70 && shoot_check_flag)
    check_time = 0;
	if(check_time > 150)
	{
		shoot_target_speed = -100;
		shoot_check_flag = 0;
		deal_check_time++;
		if(deal_check_time >= 400)  //��������һ��
		{
			shoot_check_flag = 1;
			deal_check_time = 0;
			check_time = 0;
		}
		shoot_config_L = 1;    //�����������ָ���ת
	}
	if(*Bullet_amount >= 3)  //���������������ŵ�ʱ��ֹͣת���Ҳ����п����ж�
	{
		out_speed = 0;
	}
	else
		out_speed = shoot_target_speed;
	M3508s[6].outCurrent = Incremental_PID(&M3508s[6].Speed_pid,out_speed,M3508s[6].realSpeed);
}

/**********************************************************************
  * @ ������  �� Large_Shoot
  * @ ����˵���� ���̴���
  * @ ����    �� *Bullet_amount��ǰ��������
  * @ ����ֵ  �� ��
  ********************************************************************/
int shoot_flag_L = 1;      //��ʼ����λ�������
//int shoot_time_limt = 0;   //��λ����ʱ���ж�
int shoot_limit_flag = 1;  //���������нǶ�����
float shoot_limit_angle = -58975.2f;
extern int shoot_flag_l;

void Large_Limit_shoot(int shootflag,int *Bullet_amount)
{
	if(shoot_flag_L)
	{
		M2006s[1].targetAngle = M2006s[1].realAngle;
	  shoot_flag_L = 0;	
	}
	if(shootflag && shoot_flag_l)
	{
		M2006s[1].targetAngle += shoot_limit_angle;
	}
	
	float M2006S1_PIDout = Position_PID(&M2006s[1].pid_angle,M2006s[1].targetAngle,M2006s[1].totalAngle);
	M2006s[1].outCurrent  = Position_PID(&M2006s[1].pid_speed,M2006S1_PIDout,M2006s[1].realSpeed);
  if(abs(M2006s[1].turnCount) > 100)
	{
		M2006s[1].targetAngle -= (8192 * M2006s[1].turnCount);
		M2006s[1].turnCount = 0;
	}
}


//����PID������ʼ��
void Large_shoot_PID_config(void)
{
	/*���䲦��*/
	IncrementalPID_paraReset(&M3508s[6].Speed_pid,5.5f,0.155f,11.0f,11000,1500);
	/*����Ħ����*/
	IncrementalPID_paraReset(&M3508s[4].Speed_pid,5.5f,0.155f,11.0f,8000,1500);
	IncrementalPID_paraReset(&M3508s[5].Speed_pid,5.5f,0.155f,11.0f,8000,1500);
	/*������λ*/
	PositionPID_paraReset(&M2006s[1].pid_speed,0.8,0.0f,1.0f,8000,500);
	PositionPID_paraReset(&M2006s[1].pid_angle,0.06f,0.0f,0.015f,4000,500);
}

int speed_L,speed_R;
void Control_Large_shoot(int *Bullet_amount,int shoot_flag)
{
	
	
	
	if(Key_G || dr16_data.rc.s_left == 1)
	{
		speed_L = -5000;
		speed_R = 5000;
	}
	else
	{
		speed_L = 0;
		speed_R = 0;
	}
	
//	if(dr16_data.offLineFlag)
//	{
//		speed_L = speed_R = 0;
//	  shoot_flag = 0;
//	}
//	else
//	{
//		speed_L = -0;
//	  speed_R = 0;
//	}
			
	fricMotor_setSpeed_M(speed_L,speed_R);
	Large_Limit_shoot(shoot_flag,Bullet_amount);
	Large_Shoot(Bullet_amount);
}


