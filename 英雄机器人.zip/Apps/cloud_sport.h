#ifndef CLOUD_SPORT_H
#define CLOUD_SPORT_H

#include <arm_math.h>
#include "pid.h"
#include "DR16_Receiver.h"
#include "M6020s.h"
#include "M3508s.h"
#include "GY6050s.h"


/*��������ֵ��Ҫ����鿴*/


///*�����е�޷��Ƕ�*/
//#define Normal_AngleLimit_L_L           -1800
//#define Normal_AngleLimit_R_L            2500

//#define Normal_AngleLimit_U_L            2000
//#define Normal_AngleLimit_D_L            2000

////С�����е�޷��Ƕ�
//#define Normal_AngleLimit_L_S           -1800
//#define Normal_AngleLimit_R_S            2500

//#define Normal_AngleLimit_U_S           -1800
//#define Normal_AngleLimit_D_S            2500


////С�������Ļ�е�Ƕ�
//#define X_Core_Angle_S                 1000   
//#define Y_Core_Angle_S                 1000

////�����е�Ƕ�����ֵ
//#define X_Core_Angle_L                 1000
//#define Y_Core_Angle_L                 1000
////������̨����ֵ
//#define X_Core_IMU_L                   100
//#define Y_Core_IMU_L                   200


//#define IMU_Normal                     22.75


/******************************** �Ӿ�pid���� ***********************************/

//С���Ե�һ�棺x��0.2		19			y:0.2   -7


//�Ӿ�pid��ʼ������(����)
#define VISION_X_OPID_PARAM_L \
{\
	0.12f,\
	0.0f,\
	0.0f,\
	0,\
	0,\
	0,\
	0,\
	0,\
	0,\
	0,\
	0,\
	0,\
	20000,\
	&VisionX1OPID,\
	&Pid_Rest,\
}\


#define VISION_X_IPID_PARAM_L \
{\
	0.05f,\
	0.0f,\
	0.0f,\
	0,\
	0,\
	0,\
	0,\
	0,\
	0,\
	0,\
	0,\
	0,\
	20000,\
	&VisionXIPID,\
	&Pid_Rest,\
}\


#define VISION_Y_OPID_PARAM_L \
{\
	0.8f,\
	0.0f,\
	0.0f,\
	0,\
	0,\
	0,\
	0,\
	0,\
	0,\
	0,\
	0,\
	0,\
	20000,\
	&VisionY1OPID,\
	&Pid_Rest,\
}\


#define VISION_Y_IPID_PARAM_L \
{\
	-7.0f,\
	0.0f,\
	0.0f,\
	0,\
	0,\
	0,\
	0,\
	0,\
	0,\
	0,\
	0,\
	0,\
	20000,\
	&VisionYIPID,\
	&Pid_Rest,\
}\


//�Ӿ�pid��ʼ������(С����)
#define VISION_X_OPID_PARAM_S \
{\
	0.0f,\
	0.0f,\
	0.0f,\
	0,\
	0,\
	0,\
	0,\
	0,\
	0,\
	0,\
	0,\
	0,\
	20000,\
	&VisionX1OPID,\
	&Pid_Rest,\
}\


#define VISION_X_IPID_PARAM_S \
{\
	0.0f,\
	0.0f,\
	0.0f,\
	0,\
	0,\
	0,\
	0,\
	0,\
	0,\
	0,\
	0,\
	0,\
	20000,\
	&VisionXIPID,\
	&Pid_Rest,\
}\


#define VISION_Y_OPID_PARAM_S \
{\
	0.0f,\
	0.0f,\
	0.0f,\
	0,\
	0,\
	0,\
	0,\
	0,\
	0,\
	0,\
	0,\
	0,\
	20000,\
	&VisionY1OPID,\
	&Pid_Rest,\
}\


#define VISION_Y_IPID_PARAM_S \
{\
	0.0f,\
	0.0f,\
	0.0f,\
	0,\
	0,\
	0,\
	0,\
	0,\
	0,\
	0,\
	0,\
	0,\
	20000,\
	&VisionYIPID,\
	&Pid_Rest,\
}\


typedef struct{
	float Normal_targetYaw;                     //��̨Ŀ��yaw������
	float Normal_targetPitch;                   //��̨Ŀ��pitch������
	float IMU_targetYaw;                        //��̨������yaw������
	float IMU_targetPitch;                      //��̨������pitch������
	positionpid_t IMU_YawPid_Angle;             //��̨Yaw��pid
	positionpid_t IMU_YawPid_Speed;             //��̨Yaw��pid
	positionpid_t IMU_Pitchpid_Angle;           //��̨Pitch��pid
	positionpid_t IMU_Pitchpid_Speed;           //��̨Pitch��pid
}Cloud_t;

typedef struct{
	int8_t Mode_config;
}Cloud_Control_t;


extern float vision_x,vision_y;


void cloud_IMU_sport_L(void);
void cloud_Normal_sport_L(float Cloud_Vx,float Cloud_Vy);
void cloud_Normal_sport_S(void);
void cloud_init(void);
void Small_Mode(void);
void Large_Mode(void);
void Small_Follow_Large_Normal(int16_t Cloud_Vx,int16_t Cloud_Vy);
void Cloud_Control_Normal(int16_t Cloud_Vx,int16_t Cloud_Vy);
void Volintarily_Aim(void);
void sin_Volintarily_Aim(void);
void Small_Follow_Large_IMU(float Cloud_Vx,float Cloud_Vy);
void Vision_Control_L(void);
void AiM_Sport_L(void);
void AiM_Sport_S(void);

#endif



