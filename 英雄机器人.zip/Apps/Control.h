#ifndef CONTROL_H
#define CONTROL_H

#include <arm_math.h>
#include <stdbool.h>



#define Chassis_NormalSpeed_X        1500
#define Chassis_NormalSpeed_Y        1500

/*����ٶȣ������ɳ������ݾ���*/
#define PCChassis_MaxSpeed_X           4000
#define PCChassis_MaxSpeed_Y           4000

void Control_OFF(void);
void Control_DR(void);
void Control_PC(void);
void Bullet_amount_check(void);
void APP_Init(void);



#endif



