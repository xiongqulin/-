#ifndef TASK_DISPOSE_H
#define TASK_DISPOSE_H

#include "FreeROTS_Head.h"




#define TAKS_DEBUG                0        //�Ƿ���е���



#define PC_Control                2       //���Կ���ģʽ
#define DR_Control                1       //ң��������ģʽ
#define OFF_Control               3       //�ر�

void DR16_Dispose(void* pvParameters);
void Can_Decode(void* pvParameters);
void Offline_Manage(void* pvParameters);
void Control_Task(void* pvParameters);
void DataScopeTask(void *Parameters);

#endif




