#include "chassis_sport.h"
#include "M6020s.h"
#include "M3508s.h"
#include "UserMath.h"
#include "Power.h"
Chassis_t Chassis;

/**********************************************************************
  * @ ������  �� Chassis_Init
  * @ ����˵���� ��ʼ�����̵����в���
  * @ ����    ��   
  * @ ����ֵ  �� ��
  ********************************************************************/
void Chassis_Init(void)
{
	IncrementalPID_paraReset(&M3508s[0].Speed_pid,5.5f,0.25f,12.0f,13000,2500);
	IncrementalPID_paraReset(&M3508s[1].Speed_pid,5.5f,0.25f,12.0f,13000,2500);
	IncrementalPID_paraReset(&M3508s[2].Speed_pid,5.5f,0.25f,12.0f,13000,2500);
	IncrementalPID_paraReset(&M3508s[3].Speed_pid,5.5f,0.25f,12.0f,13000,2500);
	PositionPID_paraReset(&Chassis.FollowAngle_pid,8.0f,0.0f,8.0f,4000,500);
}


/**********************************************************************
  * @ ������  �� CHASSIS_LIMIT
  * @ ����˵���� ���̵���ٶ��޷�����
  * @ ����    �� *in ���Ʋ�����MAXSPEED ����ٶ�
  * @ ����ֵ  �� ��
  **********************************`**********************************/
void CHASSIS_LIMIT(float *in,float MAXSPEED)
{
	if(*in >= MAXSPEED)
		*in = MAXSPEED;
	else if(*in <= -MAXSPEED)
		*in = -MAXSPEED;
}


/**********************************************************************
  * @ ������  �� MecanumCalculate
* @ ����˵���� Vx,Vy,VOmega,Speeds���ֽ���������ٶȴ�С
  * @ ����    ��   
  * @ ����ֵ  �� ��
  ********************************************************************/


void MecanumCalculate(float Vx, float Vy, float VOmega, int16_t *Speed)
{
    float tempSpeed[4];
	float MaxSpeed = 0.0f;
	float Param = 1.0f;
	
	
	//�ٶ�����
	VAL_LIMIT(Vx, -Chassis_MaxSpeed_X, Chassis_MaxSpeed_X);  
	VAL_LIMIT(Vy, -Chassis_MaxSpeed_Y, Chassis_MaxSpeed_Y);  
	VAL_LIMIT(VOmega, -Chassis_MaxSpeed_VOmega, Chassis_MaxSpeed_VOmega);  
	
	//�����ٶȷֽ�
	tempSpeed[0] = Vx - Vy + VOmega;
  tempSpeed[1] = Vx + Vy + VOmega;
  tempSpeed[2] = -Vx + Vy + VOmega;
  tempSpeed[3] = -Vx - Vy + VOmega;
	
    //Ѱ������ٶ�
    for(uint8_t i = 0; i < 4; i++)
    {
        if(abs(tempSpeed[i]) > MaxSpeed)
        {
            MaxSpeed = abs(tempSpeed[i]);
        }
    }
	
	
	//�ٶȷ���
    if(MaxSpeed > WheelMaxSpeed)
    {
        Param = (float)WheelMaxSpeed / MaxSpeed;
		
    }
	Speed[0] = tempSpeed[0] * Param;
	Speed[1] = tempSpeed[1] * Param;
	Speed[2] = tempSpeed[2] * Param;
	Speed[3] = tempSpeed[3] * Param;
	
}

//void MecanumCalculate(float Vx, float Vy, float VOmega, int16_t *Speed)
//{
//	float temSpeed[4];
//	float MaxSpeed = 0.0f;
//	float param = 1.0f;
//  VAL_LIMIT(Vx,-Chassis_MaxSpeed_X,Chassis_MaxSpeed_X);
//  VAL_LIMIT(Vy,-Chassis_MaxSpeed_Y,Chassis_MaxSpeed_Y);
//	VAL_LIMIT(VOmega,-Chassis_MaxSpeed_VOmega,Chassis_MaxSpeed_VOmega);

//	temSpeed[0] = Vx - Vy  + VOmega;
//	temSpeed[1] = Vx + Vy  + VOmega;
//	temSpeed[2] = -Vx + Vy + VOmega;
//	temSpeed[3] = -Vx - Vy + VOmega;
//	for(uint8_t i = 0;i < 4; i++)
//	{
//		if(temSpeed[i] > MaxSpeed)
//			MaxSpeed = abs(temSpeed[i]);
//	}
//	if(MaxSpeed > WheelMaxSpeed)
//		param = (float)WheelMaxSpeed / MaxSpeed;
//	
//	Speed[0] = temSpeed[0] * param;
//	Speed[1] = temSpeed[1] * param;
//	Speed[2] = temSpeed[2] * param;
//	Speed[3] = temSpeed[3] * param;
//}



/**********************************************************************
  * @ ������  �� chassis_sport
  * @ ����˵���� Vx,Vy,VOmega,Cloud_Angle��ǰ��̨��е�Ƕȣ�
                 Chassis_WithMode��̨׷��ģʽ��SwingModeŤ��ģʽ
  * @ ����    ��   
  * @ ����ֵ  �� ��
  ********************************************************************/
	

void chassis_sport(float Vx,float Vy,float Vomega,int Chassis_WithMode,int SwingMode)
{
	float tempFlower = 0.0f;
	int16_t speed[4];
	int16_t PID_Out[4];
	if(dr16_data.offLineFlag)
	{
		Vx = Vy = Vomega = 0.0f;
	}

	if(Chassis_WithMode == 1)
	{
		if((M6020s[1].realAngle >= (Chassis_WithAngle + Chassis_WithAngle_err)) ||
  		(M6020s[1].realAngle <= (Chassis_WithAngle - Chassis_WithAngle_err)))
		{
			Chassis.Followtarget = Position_PID(&Chassis.FollowAngle_pid,
			                                    Chassis_WithAngle,M6020s[0].totalAngle);
		  tempFlower = Chassis.Followtarget + Vomega;
		}
	}
	else
	{
		tempFlower = Vomega;
	}
	if(SwingMode == 1)
	{
	}
	MecanumCalculate(Vx,Vy,tempFlower,speed);
	for(int i = 0;i < 4; i++)
	{
		if(!M3508s[i].offLineFlag)
		{
			M3508s[i].targetSpeed = speed[i];
			PID_Out[i] = Incremental_PID(&M3508s[i].Speed_pid,M3508s[i].targetSpeed,M3508s[i].realSpeed);
			M3508s[i].infoUpdateFlag = 0;
		}
	}
	
	
	SetInPut(&powerBufferPool_t,PID_Out,4);
	for(int i = 0;i < 4;i++)
	{
		M3508s[i].outCurrent = PID_Out[i];
	}
}


