#include "cloud_sport.h"
#include "Driver_Vision.h"
#include "Monitor.h"
#include "Remote.h"

PIDRegulator_t Vision_x_OPID_L = VISION_X_OPID_PARAM_L;//�Ӿ�����x�⻷
PIDRegulator_t Vision_x_IPID_L = VISION_X_IPID_PARAM_L;//�Ӿ�����x�ڻ�

PIDRegulator_t Vision_y_OPID_L = VISION_Y_OPID_PARAM_L;//�Ӿ�����y�⻷
PIDRegulator_t Vision_y_IPID_L = VISION_Y_IPID_PARAM_L;//�Ӿ�����y�ڻ�


PIDRegulator_t Vision_x_OPID_S = VISION_X_OPID_PARAM_S;//�Ӿ�����x�⻷
PIDRegulator_t Vision_x_IPID_S = VISION_X_IPID_PARAM_S;//�Ӿ�����x�ڻ�

PIDRegulator_t Vision_y_OPID_S = VISION_Y_OPID_PARAM_S;//�Ӿ�����y�⻷
PIDRegulator_t Vision_y_IPID_S = VISION_Y_IPID_PARAM_S;//�Ӿ�����y�ڻ�

extern float vision_offset_x_l, vision_offset_y_l;

float vision_x,vision_y;
float Vision_Gry_Fuse_X_L = 0.0f,Vision_Gry_Fuse_Y_L = 0.0f;
float offset_x,offset_y;

Cloud_t  Cloud_L,Cloud_S;
Cloud_Control_t Cloud_Normal_L,Cloud_IMU_L,Cloud_Normal_S;
void Cloud_Resut(Cloud_Control_t *Cloud)
{
	Cloud->Mode_config = 1;
}

void Cloud_Init(void)
{
	Cloud_Resut(&Cloud_Normal_L);
	Cloud_Resut(&Cloud_Normal_S);
	
}
int Cloud_Normal_Config = 1;

void cloud_init(void)
{
	PositionPID_paraReset(&M6020s[0].pid_angle,0.15,0.0f,0.25f,12500,1000);
	PositionPID_paraReset(&M6020s[0].pid_speed,280.0f,0.0f,160.0f,25000,0);
	
//	PositionPID_paraReset(&M6020s[1].pid_angle,0.15f,0.0f,0.f,12500,1000);
//	PositionPID_paraReset(&M6020s[1].pid_speed,280.0f,0.0f,140.0f,25000,0);
	
	PositionPID_paraReset(&M6020s[1].pid_angle,0.225f,0.0f,0.2f,20000,1000);
	PositionPID_paraReset(&M6020s[1].pid_speed,120.0f,0.0f,60.0f,28000,0);
	
	
//	PositionPID_paraReset(&Cloud_L.IMU_YawPid_Angle,-150.0f,0.0f,-100.0f,20000,1000);
//	PositionPID_paraReset(&Cloud_L.IMU_YawPid_Speed,4.5f,0.0f,4.2f,28000,0);
//	
	/*0 ~ 360*/
//	PositionPID_paraReset(&Cloud_L.IMU_YawPid_Angle,-15.0f,0.0f,0.0f,20000,1000);
//	PositionPID_paraReset(&Cloud_L.IMU_YawPid_Speed,95.0f,0.0f,300.0f,30000,0);
//	
	/*0 ~ 8191*/
	PositionPID_paraReset(&Cloud_L.IMU_YawPid_Angle,-0.6f,0.0f,0.0f,12500,1000);
	PositionPID_paraReset(&Cloud_L.IMU_YawPid_Speed,80.0f,0.0f,200.0f,30000,0);
	
//	PositionPID_paraReset(&Cloud_L.IMU_Pitchpid_Angle,-400.0f,0.0f,-0.0f,25000,1000);
//	PositionPID_paraReset(&Cloud_L.IMU_Pitchpid_Speed,-0.75f,0.0f,-3.6f,28000,0);
	
//	PositionPID_paraReset(&Cloud_L.IMU_YawPid_Angle,-1.9f,0.0f,0.0f,12500,1000);
//	PositionPID_paraReset(&Cloud_L.IMU_YawPid_Speed,1200.0f,0.0f,0.0f,30000,0);
	
	PositionPID_paraReset(&Cloud_L.IMU_Pitchpid_Angle,0.6f	,0.0f,0.0f,12500,1000);
	PositionPID_paraReset(&Cloud_L.IMU_Pitchpid_Speed,150.0f,0.0f,50.0f,30000,0);
	
	
//		PositionPID_paraReset(&Cloud_L.IMU_Pitchpid_Angle,2.2f,0.0f,0.0f,25000,1000);
//  	PositionPID_paraReset(&Cloud_L.IMU_Pitchpid_Speed,2.2f,0.0f,0.0f,28000,0);
//		PositionPID_paraReset(&M6020s[1].pid_speed,300.0f,0.0f,60.0f,28000,0);
	
	
	
	PositionPID_paraReset(&M6020s[2].pid_angle,0.6f,0.0f,0.0f,12500,1000);
	PositionPID_paraReset(&M6020s[2].pid_speed,200.0f,0.0f,75.0f,30000,0);
	
	PositionPID_paraReset(&M6020s[3].pid_angle,0.6f,0.0f,0.0f,12500,1000);
	PositionPID_paraReset(&M6020s[3].pid_speed,200.0f,0.0f,75.0f,30000,0);
}


/*��е�Ƕȿ���ģʽ*/
void cloud_Normal_sport_L(float Cloud_Vx,float Cloud_Vy)
{
	if(Cloud_L.Normal_targetYaw > 9000)
		Cloud_L.Normal_targetYaw = 9000;
	else if(Cloud_L.Normal_targetYaw < 6200)
		Cloud_L.Normal_targetYaw = 6200;
	
	if(Cloud_L.Normal_targetPitch < 1700)
		Cloud_L.Normal_targetPitch = 1700;
	else if(Cloud_L.Normal_targetPitch > 3900)
		Cloud_L.Normal_targetPitch = 3900;
  float M6020s_0 = Position_PID(&M6020s[0].pid_angle,Cloud_L.Normal_targetYaw,M6020s[0].totalAngle);
	M6020s[0].outCurrent = Position_PID(&M6020s[0].pid_speed,M6020s_0,M6020s[0].reaSpeed);
	
	float M6020s_1 = Position_PID(&M6020s[1].pid_angle,Cloud_L.Normal_targetPitch,M6020s[1].realAngle);
	M6020s[1].outCurrent = Position_PID(&M6020s[1].pid_speed,M6020s_1,M6020s[1].reaSpeed);
}


//float IMU_Angle_Limit_XMax = 0.0f;
//float IMU_Angle_Limit_XMin = 0.0f;
//float IMU_Angle_Limit_YMax = 0.0f;
//float IMU_Angle_Limit_YMin = 0.0f;

/*�����ǿ���ģʽ*/
int PID_IMU_time = 0;
float out_coe = 0.8;
void cloud_IMU_sport_L(void)
{
	if(!M6020s[0].offLineFlag)
	{
			int32_t M6020s_0 = Position_PID(&Cloud_L.IMU_YawPid_Angle,Cloud_L.IMU_targetYaw, GY_6050[0].totalYaw);
			M6020s[0].outCurrent = Position_PID(&Cloud_L.IMU_YawPid_Speed, M6020s_0, GY_6050[0].Gyro.x);
	}
	if(!M6020s[1].offLineFlag)
	{
			int32_t M6020s_1 = Position_PID(&Cloud_L.IMU_Pitchpid_Angle,Cloud_L.IMU_targetPitch, M6020s[1].realAngle);
			M6020s[1].outCurrent = Position_PID(&Cloud_L.IMU_Pitchpid_Speed, M6020s_1,M6020s[1].reaSpeed);
	}
}


void cloud_IMU_sport_S(void)
{
	if(!M6020s[2].offLineFlag)
	{
		float M6020s_2 = Position_PID(&Cloud_S.IMU_YawPid_Angle,Cloud_S.IMU_targetYaw,GY_6050[0].totalYaw);
		M6020s[2].outCurrent = Position_PID(&Cloud_S.IMU_YawPid_Speed,M6020s_2,GY_6050[0].Gyro.x);
	}
	if(!M6020s[3].offLineFlag)
	{
		float M6020s_3 = Position_PID(&Cloud_S.IMU_Pitchpid_Angle,Cloud_S.IMU_targetPitch,GY_6050[0].totalPitch);
		M6020s[3].outCurrent = Position_PID(&Cloud_S.IMU_Pitchpid_Speed,M6020s_3,GY_6050[0].Gyro.z);
	}
}


/*С��̨*/
void cloud_Normal_sport_S(void)
{
	float M6020s_2 = Position_PID(&M6020s[2].pid_angle,Cloud_S.Normal_targetYaw,M6020s[2].realAngle);
	M6020s[2].outCurrent = Position_PID(&M6020s[2].pid_speed,M6020s_2,M6020s[2].reaSpeed);
	
	float M6020s_3 = Position_PID(&M6020s[3].pid_angle,Cloud_S.Normal_targetPitch,M6020s[3].realAngle);
	M6020s[3].outCurrent = Position_PID(&M6020s[3].pid_speed,M6020s_3,M6020s[3].reaSpeed);
}


/*��С�������*/
int16_t Small_target_Yaw = 2730;
int16_t Small_target_Pitch = 4760;
int16_t Small_target_Yaw_err = 0;
int16_t Small_target_Pitch_err = 0;

/*�Դ������*/
int16_t Large_target_Yaw = 7220;
int16_t Large_target_Pitch = 2660;
int16_t Large_target_Yaw_err = 0;
int16_t Large_target_Pitch_err = 0;

/*׷��ǶȲ�*/
int16_t Last_Large_Yaw = 0;
int16_t Err_Large_Yaw = 0;
int16_t Last_Large_Pitch = 0;
int16_t Err_Large_Pitch = 0;

int16_t target_config = 1;
/*С����׷�����*/  
void Small_Follow_Large_Normal(int16_t Cloud_Vx,int16_t Cloud_Vy)
{
	if(target_config == 1)
	{
		Cloud_L.Normal_targetYaw = M6020s[0].totalAngle;
		Cloud_L.Normal_targetPitch = M6020s[1].realAngle;
		Cloud_S.Normal_targetYaw = M6020s[2].realAngle;
		Cloud_S.Normal_targetPitch = M6020s[3].realAngle;
		
		Large_target_Yaw_err = Cloud_L.Normal_targetYaw - Large_target_Yaw;
		Large_target_Pitch_err = Cloud_L.Normal_targetPitch - Large_target_Pitch;
		
		Small_target_Yaw_err = Cloud_S.Normal_targetYaw - Small_target_Yaw;
		Small_target_Pitch_err = Cloud_S.Normal_targetPitch -  Small_target_Pitch;
		
		Last_Large_Yaw = Cloud_L.Normal_targetYaw;
		Last_Large_Pitch = Cloud_L.Normal_targetPitch;
		target_config = 0;
	}
	
	
	if(Small_target_Yaw_err > 0)
	{
		Cloud_S.Normal_targetYaw--;
	  Small_target_Yaw_err--;
	}
	else if(Small_target_Yaw_err < 0)
	{
		Cloud_S.Normal_targetYaw++;
	  Small_target_Yaw_err++;
	}
	if(Small_target_Pitch_err > 0)
	{
		Cloud_S.Normal_targetPitch--;
		Small_target_Pitch_err--;
	}
	else if(Small_target_Pitch_err < 0)
	{
		Cloud_S.Normal_targetPitch++;
		Small_target_Pitch_err++;
	}
	
	
	if(Large_target_Yaw_err > 0)
	{
		Cloud_L.Normal_targetYaw--;
		Cloud_S.Normal_targetYaw--;
		Large_target_Yaw_err--;
	}
	else if(Large_target_Yaw_err < 0)
	{
		Cloud_L.Normal_targetYaw++;
		Cloud_S.Normal_targetYaw++;
		Large_target_Yaw_err++;
	}
	if(Large_target_Pitch_err > 0)
	{
		Cloud_L.Normal_targetPitch --;
		Cloud_S.Normal_targetPitch--;
		Large_target_Pitch_err--;
	}
	else if(Large_target_Pitch_err < 0)
	{
		Cloud_L.Normal_targetPitch ++;
		Cloud_S.Normal_targetPitch++;
		Large_target_Pitch_err++;
	}
	
	Err_Large_Yaw = 	Cloud_L.Normal_targetYaw - Last_Large_Yaw; 
	Err_Large_Pitch =  Cloud_L.Normal_targetPitch - Last_Large_Pitch;
	
	Cloud_S.Normal_targetPitch -= Err_Large_Pitch;
	Cloud_S.Normal_targetYaw -= Err_Large_Yaw;
	Last_Large_Yaw = Cloud_L.Normal_targetYaw;
	Last_Large_Pitch = Cloud_L.Normal_targetPitch;
	
	
	Cloud_L.Normal_targetPitch += Cloud_Vy;
	Cloud_L.Normal_targetYaw += Cloud_Vx;
  
}




//С����Ƕ�׷�����
/*��С�������*/
int16_t Small_target_NormalYaw = 2750;
int16_t Small_target_NormalPitch = 4800;
int16_t Small_target_NormalYaw_err = 0;
int16_t Small_target_NormalPitch_err = 0;

/*�Դ������*/
//��е�Ƕ�Ŀ��ֵ
int16_t Large_target_NormalYaw = 7400;
int16_t Large_target_NormalPitch = 2700;
int16_t Large_target_NormalYaw_err = 0;
int16_t Large_target_NormalPitch_err = 0;

//��е�Ƕ��޷������ǽǶ�
int16_t Large_target_NormalYaw_Max = 8300;
int16_t Large_target_NormalYaw_Min = 6400;
int16_t Large_target_NormalPitch_Max = 3500;
int16_t Large_target_NormalPitch_Min = 2200;


int32_t Large_target_IMUYaw_Max = 0.0f;
int32_t Large_target_IMUYaw_Min = 0.0f;


//������Ŀ��ֵ
float   Large_IMU_Target_Yaw_err = 0.0f;
float   Large_IMU_Target_Pitch_err = 0.0f;

/*׷��ǶȲ�*/
int16_t Last_Large_IMUYaw = 0;
int16_t Err_Large_IMUYaw = 0;
int16_t Last_Large_IMUPitch = 0;
int16_t Err_Large_IMUPitch = 0;
int16_t Last_Yaw = 0;
int16_t Last_Pitch = 0;
int16_t Normal_Yaw_Err = 0;
int16_t Normal_Pitch_Err = 0;

int16_t Real_Yaw = 0;
int16_t Real_Pitch = 0;

int16_t target_IMUconfig = 1;

void Small_Follow_Large_IMU(float Cloud_Vx,float Cloud_Vy)
{
	if(target_IMUconfig)
	{
		Cloud_L.IMU_targetYaw = GY_6050[0].totalYaw;
		Cloud_L.IMU_targetPitch = M6020s[1].realAngle;
		
		Cloud_L.Normal_targetYaw = Last_Yaw = M6020s[0].totalAngle;
	  Cloud_L.Normal_targetPitch = Last_Pitch = M6020s[1].realAngle;	
		
		Real_Yaw = M6020s[2].realAngle;
		Real_Pitch = M6020s[3].realAngle;
		
		
		Small_target_NormalYaw_err = Real_Yaw - Small_target_NormalYaw;
		Small_target_NormalPitch_err = Real_Pitch - Small_target_NormalPitch;
		
		Large_target_NormalYaw_err = M6020s[0].totalAngle - Large_target_NormalYaw;
		Large_target_NormalPitch_err = M6020s[1].realAngle - Large_target_NormalPitch;
		
		target_IMUconfig = 0;
	}

		
	
	//�����ǳ�ʼλ�� ������̨׷��ʱ���裩
//	if(Large_IMU_Target_Yaw_err > 0.1f)
//	{
//		Large_IMU_Target_Yaw_err -= 0.1f;
//		Cloud_L.IMU_targetYaw -= 0.1f;
//	
//	}
//	else if(Large_IMU_Target_Yaw_err < -0.1f)
//	{
//		Large_IMU_Target_Yaw_err += 0.1f;
//		Cloud_L.IMU_targetYaw += 0.1f;
//	}
	
//	if(Large_IMU_Target_Pitch_err > 0.1f)
//	{
//		Large_IMU_Target_Pitch_err -= 0.1f;
//		Cloud_L.IMU_targetPitch -= 0.1f;
//	
//	}
//	else if(Large_IMU_Target_Pitch_err < -0.1f)
//	{
//		Large_IMU_Target_Pitch_err += 0.1f;
//		Cloud_L.IMU_targetPitch += 0.1f;
//	}
	
	//С����λ�ó�ʼ��
	if(Small_target_NormalYaw_err > 0)
	{
		Real_Yaw--;
	  Small_target_NormalYaw_err--;
	}
	else if(Small_target_NormalYaw_err < 0)
	{
		Real_Yaw++;
	  Small_target_NormalYaw_err++;
	}
	
	if(Small_target_NormalPitch_err > 0)
	{
		Real_Pitch--;
		Small_target_NormalPitch_err--;
	}
	else if(Small_target_NormalPitch_err < 0)
	{
		Real_Pitch++;
		Small_target_NormalPitch_err++;
	}
	 
	//����λ�ó�ʼ��������С������
	if(Large_target_NormalYaw_err > 0)
	{
		Real_Yaw--;
		Large_target_NormalYaw_err--;
	}
	else if(Large_target_NormalYaw_err < 0)
	{
		Real_Yaw++;
		Large_target_NormalYaw_err++;
	}
	
	if(Large_target_NormalPitch_err > 0)
	{
		
		Real_Pitch--;
		Large_target_NormalPitch_err--;
		Cloud_L.IMU_targetPitch--;
	}
	else if(Large_target_NormalPitch_err < 0)
	{
		Real_Pitch++;
		Large_target_NormalPitch_err++;
		Cloud_L.IMU_targetPitch++;
	}
	
	
	
	Normal_Yaw_Err = M6020s[0].totalAngle - Last_Yaw;
	Normal_Pitch_Err = M6020s[1].realAngle - Last_Pitch;
	
	Real_Yaw -= Normal_Yaw_Err;
	Real_Pitch -= Normal_Pitch_Err;
	
	
	Cloud_S.Normal_targetYaw = Real_Yaw;
	Cloud_S.Normal_targetPitch = Real_Pitch;
	
	LIMIT(Cloud_Vx,20);
	LIMIT(Cloud_Vy,20);

   int16_t IMU_ERR = M6020s[0].totalAngle - 7400;
   Large_target_IMUYaw_Min = GY_6050[0].totalYaw + IMU_ERR - 1000;
	 Large_target_IMUYaw_Max = GY_6050[0].totalYaw + IMU_ERR + 1000;
	
	Cloud_L.IMU_targetYaw += Cloud_Vx;
	Cloud_L.IMU_targetPitch += Cloud_Vy;
	if(Cloud_L.IMU_targetYaw >= Large_target_IMUYaw_Max)
		Cloud_L.IMU_targetYaw = Large_target_IMUYaw_Max;
	if(Cloud_L.IMU_targetYaw <= Large_target_IMUYaw_Min)
		Cloud_L.IMU_targetYaw = Large_target_IMUYaw_Min;
	if(Cloud_L.IMU_targetPitch > 3600)
		Cloud_L.IMU_targetPitch  = 3600;
	if(Cloud_L.IMU_targetPitch < 2200)
		Cloud_L.IMU_targetPitch  = 2200;
	
	
	
	//�޷�
	if(Cloud_S.Normal_targetYaw < 2400)
		Cloud_S.Normal_targetYaw = 2400;
	else if(Cloud_S.Normal_targetYaw > 3300)
		Cloud_S.Normal_targetYaw = 3300;
	if(Cloud_S.Normal_targetPitch < 4500)
		Cloud_S.Normal_targetPitch = 4500;
	else if(Cloud_S.Normal_targetPitch > 5100)
		Cloud_S.Normal_targetPitch = 5100;

	Last_Yaw = M6020s[0].totalAngle;
	Last_Pitch = M6020s[1].realAngle;
}


void Cloud_Control_Normal(int16_t Cloud_Vx,int16_t Cloud_Vy)
{
	Small_Follow_Large_Normal(Cloud_Vx,Cloud_Vy);
	cloud_Normal_sport_L(0,0);
	cloud_Normal_sport_S();
}


int8_t sin_targe_config = 1;
int8_t sin_flag = 0;
int16_t sin_target_X = 0;
int16_t sin_target_Y = 0;
int16_t cycle = 450;       //��������

void sin_Volintarily_Aim(void)
{
	if(sin_targe_config)
	{
		Cloud_S.Normal_targetYaw = M6020s[2].realAngle;
		Cloud_S.Normal_targetPitch = M6020s[3].realAngle;
		sin_target_X = Cloud_S.Normal_targetYaw - 2400;
		sin_target_Y = sin_target_X;
		sin_targe_config = 0;
	}
	
		if(sin_target_X > 900)
			sin_flag = 0;
		else if(sin_target_X < 0)
			sin_flag = 1;
		
		if(sin_flag)
			sin_target_X += 3;
		else
			sin_target_X -= 3;
		
		sin_target_Y += 3;
		if(sin_target_Y > 10 * cycle)
			sin_target_Y -= 10 * cycle;
		Cloud_S.Normal_targetPitch = (int)(4800 + 300*sin(((2*M_PI) / cycle) * sin_target_Y));
		Cloud_S.Normal_targetYaw = 2400 + sin_target_X;
}

/**
	* @brief  �Ӿ����ƺ���
  * @param	void
  * @retval None
  */



void Vision_Control_L(void)
{
//	if(!LostCounterCheck(LOST_ERROR_YAWMOTOR)//�豸�Ƿ�����
//			&& !LostCounterCheck(LOST_ERROR_VISION))
//	{
			
//			vision_y = Vision_y_IPID_L.Output 
//							 + GY_6050[0].Gyro.z * Vision_Gry_Fuse_Y_L;	
//	}
}

void Vision_Control_S(void)
{
	Vision_x_OPID_L.Calc(&Vision_x_OPID_L, 
													 vision_offset_x_l, 
													  GetCoordx(VISION_X));
	Vision_x_IPID_L.Calc(&Vision_x_IPID_L,
													 Vision_x_OPID_L.Output,
														GetCorrdxDiff(VISION_X));
			
	Vision_y_OPID_L.Calc(&Vision_y_OPID_L, 
													 vision_offset_y_l, 
														GetCoordx(VISION_Y));			
	Vision_y_IPID_L.Calc(&Vision_y_IPID_L, 
													Vision_y_OPID_L.Output, 
													 GetCorrdxDiff(VISION_Y));
			
	vision_x = Vision_x_IPID_L.Output
							 + GY_6050[0].Gyro.x * Vision_Gry_Fuse_X_L;	
}


void AiM_Sport_L(void)
{
	if(!M6020s[0].offLineFlag)
	{
			int16_t M6020s_0 = Position_PID(&Cloud_L.IMU_YawPid_Angle, GY_6050[0].totalYaw, GY_6050[0].totalYaw + vision_x);
			M6020s[0].outCurrent = Position_PID(&Cloud_L.IMU_YawPid_Speed, M6020s_0, GY_6050[0].Gyro.x);
	}
	if(!M6020s[1].offLineFlag)
	{
			float M6020s_1 = Position_PID(&Cloud_L.IMU_Pitchpid_Angle,2550, M6020s[1].realAngle);
			M6020s[1].outCurrent = Position_PID(&Cloud_L.IMU_Pitchpid_Speed, M6020s_1,M6020s[1].reaSpeed);
	}
}

void AiM_Sport_S(void)
{
	
}





