#ifndef __SHOOT_STATUS_H
#define __SHOOT_STATUS_H

#include <arm_math.h>


typedef enum{
	One_Level = 1,
	Two_Level = 2,
	Three_Level = 3,
}RobotLever_e;


//typedef struct{

//	
//}shoot_Gun_t;

////void Heat_Calculation(void);
////void Lever_Determine(uint8_t lever);
void shoot_deal(void);

#endif

