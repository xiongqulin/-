/**
  ******************************************************************************
  * @file    Rocker.c
  * @author  Hare
  * @version V1.0
  * @date    
  * @brief   DR16????????
  ******************************************************************************
  */
  
  
#include "Rocker.h"


/**
  * @brief  ?xy????????
  * @param[in]  posX		x??
  *				posY		y??
  * @param[out]	*roc	 	????
  * @retval None
  */

/*************************?????????????X,Y?********************/
void Rocker_getData(float posX, float posY, rocker_t *roc){
	roc->x = posX;
	roc->y = posY;

		roc->degrees=atan2(roc->y, roc->x)* 180.0f / PI;
#if __FPU_PRESENT
	/*
	sqrt????
	sqrt???????
	double sqrt(double x);
	float sqrtf(float x);
	long double sqrtl(long double x);
	float????,double??,long double?????
	*/
	/*
	pow() ????? x ? y ??(??),x?y??????double? ,????:
  double pow(double x, double y);
	*/
	roc->distance = __sqrtf(pow(roc->x, 2) + pow(roc->y, 2));
#else
	roc->distance = sqrt(pow(roc->x, 2) + pow(roc->y, 2));
#endif
 /**********************???????????********************************/
	if(roc->degrees>180){
      roc->distance = -roc->distance;
      //rocL->degrees = -rocL->degrees + 360.0f;
    }
}

