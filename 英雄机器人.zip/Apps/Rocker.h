#ifndef __ROCKER_H
#define __ROCKER_H

#include <arm_math.h>
typedef struct {
	float x;
	float y;
	float radian;
	float degrees;
	float distance;
}rocker_t;

void Rocker_getData(float posX, float posY, rocker_t *roc);
 
#endif /* __ROCKER_H */
