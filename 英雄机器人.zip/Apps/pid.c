#include "pid.h"


/**********************************************************************
  * @ ������  �� abs_limit
  * @ ����˵���� ��PID�������daxi�Ĵ�С�����޷�
  * @ ����    �� *inҪ��ֵ��ָ�룬�޷����ֵ
  * @ ����ֵ  �� ��
  ********************************************************************/

void abs_limit(float *a, float ABS_MAX){
    if(*a > ABS_MAX)
        *a = ABS_MAX;
    if(*a < -ABS_MAX)
        *a = -ABS_MAX;
}
/**********************************************************************
  * @ ������  �� ZeroPoint_Deal
  * @ ����˵���� ����������ʱ����й��㴦���޸����
  * @ ����    �� *err�������ֵ
  * @ ����ֵ  �� ��
  ********************************************************************/
void ZeroPoint_Deal(float *err)
{
	float temp    = 0.0f;
	float abs_err = 0.0f;
	if(*err > 0)
		abs_err = *err;
	else if(*err < 0)
		abs_err = -*err;
	temp = total_angle - abs_err;
	if(abs_err > temp)
		abs_err = temp;
	if(*err > 0)
		*err  = abs_err;
	else if(*err < 0)
		*err  = -abs_err;
}

/**********************************************************************
  * @ ������  �� Incremental_Pid_Parameter
  * @ ����˵���� ��ʼ������ʽPID����
  * @ ����    �� *pid����ʽPID�ṹ��ָ�룬Kp,Ki,Kd pid������Max pid��������
                 Limit ������������
  * @ ����ֵ  �� ��
  ********************************************************************/
void Incremental_Pid_Parameter(incremental_pid *pid,float Kp,float Ki,float Kd
	                                                ,uint32_t Max,uint32_t Limit)
{
	pid->before_err = 0.0f;
	pid->err = 0.0f;
	pid->IntegralLimit = Limit;
	pid->kd = Kd;
	pid->ki = Ki;
	pid->kp = Kp;
	pid->last_err = 0.0f;
	pid->MaxOut = Max;
  pid->measure = 0.0f;
  pid->out_pwm = 0.0f;
  pid->target = 0.0f;	
}
	


/**********************************************************************
  * @ ������  �� Incremental_pid
  * @ ����˵���� ����ʽPID
  * @ ����    �� *pid����ʽPID�ṹ��ָ�룬targetĿ��ֵ��mesasure����ֵ
  * @ ����ֵ  �� pid->out_pwm��PID���������
  ********************************************************************/
float Incremental_pid(incremental_pid *pid, float target, float measured) {
	float p_out, i_out, d_out;
	pid->target = target;
	pid->measure = measured;
	pid->err = pid->target - pid->measure;
	

	p_out = pid->kp *(pid->err - pid->last_err);
	i_out = pid->ki * pid->err;
	d_out = pid->kd *(pid->err - 2.0f*pid->last_err + pid->before_err);

	abs_limit(&i_out, pid->IntegralLimit);
	
	pid->out_pwm += (p_out + i_out + d_out);

	abs_limit(&pid->out_pwm, pid->MaxOut);
	
	pid->before_err = pid->last_err;
	pid->last_err = pid->err;
	return pid->out_pwm;
}


void IncrementalPID_paraReset(incrementalpid_t *pid_t, float kp, float ki, float kd, uint32_t MaxOutput, uint32_t IntegralLimit){
	pid_t->Target = 0;
	pid_t->Measured = 0;
	pid_t->err = 0;
	pid_t->err_last = 0;
	pid_t->err_beforeLast = 0;
	pid_t->Kp = kp;
	pid_t->Ki = ki;
	pid_t->Kd = kd;
	pid_t->MaxOutput = MaxOutput;
	pid_t->IntegralLimit = IntegralLimit;
	pid_t->pwm = 0; 			
}

int err_time1,err_time2;
float Incremental_PID(incrementalpid_t *pid_t, float target, float measured) {
	float p_out, i_out, d_out;
	pid_t->Target = target;
	pid_t->Measured = measured;
	pid_t->err = pid_t->Target - pid_t->Measured;
	
	p_out = pid_t->Kp*(pid_t->err - pid_t->err_last);
	i_out = pid_t->Ki*pid_t->err;
	d_out = pid_t->Kd*(pid_t->err - 2.0f*pid_t->err_last + pid_t->err_beforeLast);
	
	//�����޷�
	abs_limit(&i_out, pid_t->IntegralLimit);
	
	pid_t->pwm += (p_out + i_out + d_out);
	
	//����޷�
	abs_limit(&pid_t->pwm, pid_t->MaxOutput);
	
	pid_t->err_beforeLast = pid_t->err_last;
	pid_t->err_last = pid_t->err;

	return pid_t->pwm;
}

/**********************************************************************
  * @ ������  �� Postion_pid_Parameter
  * @ ����˵���� ��ʼ��λ��ʽPID����
  * @ ����    �� *pidλ��ʽPID�ṹ��ָ�룬Kp,Ki,Kd pid������Max pid��������
                 Limit ������������
  * @ ����ֵ  �� ��
  ********************************************************************/ 
void Postion_pid_Parameter(Position_pid *pid,float Kp,float Ki,float Kd
	                                         ,uint32_t Max,uint32_t Limit)
{
	pid->err = 0.0f;
	pid->IntegralLimit = Limit;
	pid->kd = Kd;
	pid->ki = Ki;
	pid->kp = Kp;
	pid->last_err = 0.0f;
	pid->MaxOut = Max;
	pid->measure = 0.0f;
	pid->out_pwm = 0.0f;
	pid->target = 0.0f;
	pid->total_err = 0;
}




float Postion_pid(Position_pid *pid_t,float target,float measured,int mode)
{
	float p_out,i_out,d_out;
	pid_t->target = target;
	pid_t->measure = measured;
  pid_t->err = pid_t->target - pid_t->measure;

	pid_t->total_err += pid_t->err;
	p_out = pid_t->kp * pid_t->err;
	i_out = pid_t->ki * pid_t->total_err;
	d_out = pid_t->kd * (pid_t->err - pid_t->last_err);
	
	//�����޷�
	abs_limit(&i_out,pid_t->IntegralLimit);
	pid_t->out_pwm = p_out + i_out + d_out;
	abs_limit(&pid_t->out_pwm,pid_t->MaxOut);
	pid_t->last_err = pid_t->err;

  return pid_t->out_pwm;
}


void PositionPID_paraReset(positionpid_t *pid_t, float kp, float ki, float kd, uint32_t MaxOutput, uint32_t IntegralLimit){
	pid_t->Target = 0;
	pid_t->Measured = 0;
	pid_t->MaxOutput = MaxOutput;
	pid_t->IntegralLimit = IntegralLimit;
	pid_t->err = 0;
	pid_t->err_last = 0;
	pid_t->integral_err = 0;
	pid_t->Kp = kp;
	pid_t->Ki = ki;
	pid_t->Kd = kd;
	pid_t->pwm = 0; 			
}


float Position_PID(positionpid_t *pid_t, float target, float measured) {
	pid_t->Target = (float)target;
	pid_t->Measured = (float)measured;
	pid_t->err = pid_t->Target - pid_t->Measured;
	//���㴦��
//	ZeroPoint_Deal(&pid_t->err);
	
//	if(abs(pid_t->err)<0.2f)
//		pid_t->err = 0.0f;
		//return 0;
	if(pid_t->err <= 200)
	   pid_t->integral_err += pid_t->err;
	else
		pid_t->integral_err = 0;
		 
	
	pid_t->p_out = pid_t->Kp*pid_t->err;
	pid_t->i_out = pid_t->Ki*pid_t->integral_err;
	pid_t->d_out = pid_t->Kd*(pid_t->err - pid_t->err_last);
	
	
	
	//�����޷�
	abs_limit(&pid_t->i_out, pid_t->IntegralLimit);
	
	pid_t->pwm = (pid_t->p_out + pid_t->i_out + pid_t->d_out);
	
	//����޷�
	abs_limit(&pid_t->pwm, pid_t->MaxOutput);
	
	pid_t->err_last = pid_t->err;

	return pid_t->pwm;
}

float Position_PID_Yaw(positionpid_t *pid_t, float target, float measured) {
	pid_t->Target = (float)target;
	pid_t->Measured = (float)measured;
	pid_t->err = pid_t->Target - pid_t->Measured;
	if (pid_t->err>4095) pid_t->err -= 8190;
	if (pid_t->err<-4095) pid_t->err += 8190;
	//���㴦��
//	ZeroPoint_Deal(&pid_t->err);
	
//	if(abs(pid_t->err)<0.2f)
//		pid_t->err = 0.0f;
		//return 0;
	if(pid_t->err <= 200)
	   pid_t->integral_err += pid_t->err;
	else
		pid_t->integral_err = 0;
		 
	
	pid_t->p_out = pid_t->Kp*pid_t->err;
	pid_t->i_out = pid_t->Ki*pid_t->integral_err;
	pid_t->d_out = pid_t->Kd*(pid_t->err - pid_t->err_last);
	
	
	
	//�����޷�
	abs_limit(&pid_t->i_out, pid_t->IntegralLimit);
	
	pid_t->pwm = (pid_t->p_out + pid_t->i_out + pid_t->d_out);
	
	//����޷�
	abs_limit(&pid_t->pwm, pid_t->MaxOutput);
	
	pid_t->err_last = pid_t->err;

	return pid_t->pwm;
}

/**
	* @brief  ����pid����
  * @param	PIDRegulator_t *pid_t  Ŀ��ֵ ��ȡֵ
  * @retval None
  */
void Increment_Pid( PIDRegulator_t *pid_t,float TargetValue,float RealValue)
{
	if (pid_t == 0)
	{
		return ;
	}
	
	pid_t->Error= TargetValue - RealValue;
	
	pid_t->KpOut = pid_t->Kp*(pid_t->Error - pid_t->LastError);
	pid_t->KiOut = pid_t->Ki*pid_t->Error;
	pid_t->KdOut = pid_t->Kd*(pid_t->Error - 2.0f*pid_t->LastError + pid_t->PrevError);
	
	pid_t->Output += pid_t->KpOut+ pid_t->KiOut + pid_t->KdOut;
	
	//�޷�
	LIMIT(pid_t->Output, pid_t->OutputMax);
	
	pid_t->PrevError = pid_t->LastError;
	pid_t->LastError = pid_t->Error;
	
	//�޷�
	LIMIT(pid_t->Output, pid_t->OutputMax);
	
	pid_t->PrevError = pid_t->LastError;
	pid_t->LastError = pid_t->Error;
}


/**
	* @brief  �Ӿ�xPID--�⻷
  * @param	PIDRegulator_t *pid_t
  * @retval None
  */
float t1 = -15.0f,t2 = -28.0f,t3 = -38.0f,t4 = -45.0f,t5 = -55.0f,t6 = -30.0f;//��������
void VisionXOPID(PIDRegulator_t *pid_t, float TargetValue, float RealValue)
{
	if (pid_t == 0)
	{
		return ;
	}
	pid_t->Error = TargetValue - RealValue;
	 	
	pid_t->Integral += pid_t->Error;//����
	
	LIMIT(pid_t->Integral, pid_t->IOutMax);
	
	
	if (abs(RealValue) > 80)
	{
		pid_t->Kp = t1;
	}
	else if (abs(RealValue) > 60)
	{
		pid_t->Kp = t2;
	}
	else if (abs(RealValue) > 40)
	{
		pid_t->Kp = t3;
	}
	else if (abs(RealValue) > 20)
	{
		pid_t->Kp = t4;		
	}
	else if (abs(RealValue) > 5)
	{
		pid_t->Kp = t5;	
	}
	else
	{
		pid_t->Kp = t6;
	}

	
	pid_t->KpOut = pid_t->Kp*pid_t->Error;
	pid_t->KiOut = pid_t->Ki*pid_t->Integral;
	pid_t->KdOut = pid_t->Kd*(pid_t->Error - pid_t->LastError);
	
	pid_t->Output = pid_t->KpOut + pid_t->KiOut + pid_t->KdOut;
	
		//�޷�
	LIMIT(pid_t->Output, pid_t->OutputMax);
	pid_t->PrevError = pid_t->LastError;
	pid_t->LastError = pid_t->Error;
}


/**
	* @brief  �Ӿ�x1PID--�⻷
  * @param	PIDRegulator_t *pid_t
  * @retval None
  */
void VisionX1OPID(PIDRegulator_t *pid_t, float TargetValue, float RealValue)
{
	if (pid_t == 0)
	{
		return ;
	}
	pid_t->Error = TargetValue - RealValue;
	 	
	pid_t->Integral += pid_t->Error;//����
	
	
	LIMIT(pid_t->Integral, pid_t->IOutMax);
	
	
	pid_t->KpOut = pid_t->Kp*pid_t->Error;
	pid_t->KiOut = pid_t->Ki*pid_t->Integral;
	pid_t->KdOut = pid_t->Kd*(pid_t->Error - pid_t->LastError);
	
	pid_t->Output = pid_t->KpOut + pid_t->KiOut + pid_t->KdOut;
	
		//�޷�
	LIMIT(pid_t->Output, pid_t->OutputMax);
	pid_t->PrevError = pid_t->LastError;
	pid_t->LastError = pid_t->Error;
}



/**
	* @brief  �Ӿ�x1PID--�ڻ�
  * @param	PIDRegulator_t *pid_t
  * @retval None
  */
void VisionXIPID(PIDRegulator_t *pid_t, float TargetValue, float RealValue)
{
	if (pid_t == 0)
	{
		return ;
	}
	pid_t->Error = TargetValue - RealValue;

	pid_t->Integral += pid_t->Error;//����
	
	LIMIT(pid_t->Integral, pid_t->IOutMax);
	
	pid_t->KpOut = pid_t->Kp*pid_t->Error;
	pid_t->KiOut = pid_t->Ki*pid_t->Integral;
	pid_t->KdOut = pid_t->Kd*(pid_t->Error - pid_t->LastError);
	

	pid_t->Output = pid_t->KpOut + pid_t->KiOut + pid_t->KdOut;
	
		//�޷�
	LIMIT(pid_t->Output, pid_t->OutputMax);
	pid_t->PrevError = pid_t->LastError;
	pid_t->LastError = pid_t->Error;
	
}


float T1 = -20,T2 = -25,T3 = -28,T4 = -30,T5 = -35,T6 = -5;


/**
	* @brief  �Ӿ�yPID--�⻷
  * @param	PIDRegulator_t *pid_t
  * @retval None
  */
void VisionYOPID(PIDRegulator_t *pid_t, float TargetValue, float RealValue)
{
	if (pid_t == 0)
	{
		return ;
	}
	pid_t->Error = TargetValue - RealValue;
	 	
	pid_t->Integral += pid_t->Error;//����
	
	LIMIT(pid_t->Integral, pid_t->IOutMax);
	
	
	if (ABS(RealValue) > 80)
	{
		pid_t->Kp = T1;
	}
	else if (ABS(RealValue) > 60)
	{
		pid_t->Kp = T2;
	}
	else if (ABS(RealValue) > 40)
	{
		pid_t->Kp = T3;
	}
	else if (ABS(RealValue) > 20)
	{
		pid_t->Kp = T4;		
	}
	else if (ABS(RealValue) > 5)
	{
		pid_t->Kp = T5;	
	}
	else
	{
		pid_t->Kp = T6;
	}

	
	pid_t->KpOut = pid_t->Kp*pid_t->Error;
	pid_t->KiOut = pid_t->Ki*pid_t->Integral;
	pid_t->KdOut = pid_t->Kd*(pid_t->Error - pid_t->LastError);
	
	pid_t->Output = pid_t->KpOut + pid_t->KiOut + pid_t->KdOut;
	
		//�޷�
	LIMIT(pid_t->Output, pid_t->OutputMax);
	pid_t->PrevError = pid_t->LastError;
	pid_t->LastError = pid_t->Error;
}



/**
	* @brief  �Ӿ�yPID--�⻷
  * @param	PIDRegulator_t *pid_t
  * @retval None
  */
void VisionY1OPID(PIDRegulator_t *pid_t, float TargetValue, float RealValue)
{
	if (pid_t == 0)
	{
		return ;
	}
	pid_t->Error = TargetValue - RealValue;
	 	
	pid_t->Integral += pid_t->Error;//����
	
	LIMIT(pid_t->Integral, pid_t->IOutMax);
	
	pid_t->KpOut = pid_t->Kp*pid_t->Error;
	pid_t->KiOut = pid_t->Ki*pid_t->Integral;
	pid_t->KdOut = pid_t->Kd*(pid_t->Error - pid_t->LastError);
	
	pid_t->Output = pid_t->KpOut + pid_t->KiOut + pid_t->KdOut;
	
		//�޷�
	LIMIT(pid_t->Output, pid_t->OutputMax);
	pid_t->PrevError = pid_t->LastError;
	pid_t->LastError = pid_t->Error;
}


/**
	* @brief  �Ӿ�yPID--�ڻ�
  * @param	PIDRegulator_t *pid_t
  * @retval None
  */
void VisionYIPID(PIDRegulator_t *pid_t, float TargetValue, float RealValue)
{
	if (pid_t == 0)
	{
		return ;
	}
	pid_t->Error = TargetValue - RealValue;

	pid_t->Integral += pid_t->Error;//����
	
	LIMIT(pid_t->Integral, pid_t->IOutMax);
	
	pid_t->KpOut = pid_t->Kp*pid_t->Error;
	pid_t->KiOut = pid_t->Ki*pid_t->Integral;
	pid_t->KdOut = pid_t->Kd*(pid_t->Error - pid_t->LastError);
	

	pid_t->Output = pid_t->KpOut + pid_t->KiOut + pid_t->KdOut;
	
		//�޷�
	LIMIT(pid_t->Output, pid_t->OutputMax);
	pid_t->PrevError = pid_t->LastError;
	pid_t->LastError = pid_t->Error;
	
}


/**
	* @brief  PidĬ��ֵ
  * @param	PIDRegulator_t *pid_t
  * @retval None
  */
void Pid_Rest( PIDRegulator_t *pid_t)
{
	pid_t->Error = 0.0;
	pid_t->Integral = 0.0;
	pid_t->LastError = 0.0;
	pid_t->PrevError = 0.0;
	pid_t->Output = 0.0;
}


//void PositionPID_Calculation(positionpid_t *pid, float target, float measured)
//{
//    float kp_output,ki_output,kd_output;
////		static float Format_kd = ;
//	
//		
//    pid->Target = (float)target;
//    pid->Measured = (float)measured;
//    pid->error = pid->Target - pid->Measured;
//		
//		/*��PID����*/
////		if(pid->error < -6000)
////		{
////				pid->error = (pid->Target+8192)-	pid->Measured;
////		}
////		if(pid->error > 6000)
////		{
////				pid->error = pid->Target - (pid->Measured + 8192);
////		}
////		
//    /*���ַ���*/
//		if(ABS(pid->error) < 20)
//		{
//			pid->Add_error += pid->error;
//		}
//    

//    /*λ��ʽPID���㹫ʽ*/
//    pid->Kp_Output = pid->Kp * pid->error;
//    pid->Ki_Output = pid->Ki * pid->Add_error;
//    pid->Kd_Output = pid->Kd * (pid->error - pid->last_error);
//		

//    pid->PWM = (pid->Kp_Output + pid->Ki_Output + pid->Kd_Output);


//    pid->last_error = pid ->error;

//}

///**
//	* @brief  λ��pid����
//  * @param	PIDRegulator_t *pid_t  Ŀ��ֵ ��ȡֵ
//  * @retval None
//  */
//void ChassisFollow_PID( PIDRegulator_t *pid_t, float TargetValue, float RealValue)
//{
//	if (pid_t == NULL)
//	{
//		return ;
//	}
//	
//	pid_t->Error = TargetValue - RealValue;
//		
//	pid_t->Integral += pid_t->Error;//����
//	
//	LIMIT(pid_t->Integral, pid_t->IOutMax);
//		
//	pid_t->KpOut = pid_t->Kp*pid_t->Error;
//	pid_t->KiOut = pid_t->Ki*pid_t->Integral;
//	pid_t->KdOut = pid_t->Kd*(pid_t->Error - pid_t->LastError);
//	

//	pid_t->Output = pid_t->KpOut + pid_t->KiOut + pid_t->KdOut;
//	
//	//�޷�
//	LIMIT(pid_t->Output, pid_t->OutputMax);
//	
//	pid_t->PrevError = pid_t->LastError;
//	pid_t->LastError = pid_t->Error;
//	
//}


