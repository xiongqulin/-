#include "Offline_Manage.h"
#include "DR16_Receiver.h"
#include "GY6050s.h"
#include "M3508s.h"
#include "M2006s.h"
#include "M6020s.h"
#include "Driver_Vision.h"


void Offline(void)
{
	/*ң����֡�ʼ��*/
	if(dr16_data.infoUpdateFrame <= 3)
	{
		dr16_data.offLineFlag = 1;
	}
	else
	{
		dr16_data.offLineFlag = 0;
	}
	dr16_data.infoUpdateFrame = 0;
	
	 /*������֡�ʼ��*/
	if(GY_6050[0].ImuInfoUpdateFrame <= 5)
	{
		GY_6050[0].ImuOffLineFlag = 1;
	}
	else
	{
		GY_6050[0].ImuOffLineFlag = 0;
	}
	GY_6050[0].ImuInfoUpdateFrame = 0;
	

	/*M3508s ֡�ʼ��*/
	for(int i= 0;i < 7;i++)
	{
		if(M3508s[i].infoUpdateFrame <= 5)
		{
			M3508s[i].offLineFlag = 1;
		}
		else
		{
			M3508s[i].offLineFlag = 0;
		}
		M3508s[i].infoUpdateFrame = 0;
	}
	

	
	/*M2006s ֡�ʼ��*/
	for(int i = 0; i < 2;i++)
	{
		if(M2006s[i].infoUpdateFrame <= 5)
		{
			M2006s[i].offLineFlag = 1;
		}
		else
		{
			M2006s[i].offLineFlag = 0;
		}
		M2006s[i].infoUpdateFrame = 0;
  }
	
  /*M6020s֡�ʼ��*/
	for(int i = 0;i < 4;i++)
	{
		if(M6020s[i].infoUpdateFrame <= 5)
		{
			M6020s[i].offLineFlag = 1;
		}			
		else
		{
			M6020s[i].offLineFlag = 0;
		}
		M6020s[i].infoUpdateFrame = 0;
	}
	
	if(VisionData.infoUpdateFrame < 5)
	{
		VisionData.offLineFlag = 1;
	}
	else
		VisionData.offLineFlag = 0;
	VisionData.infoUpdateFrame = 0;\
	
	
	
}



