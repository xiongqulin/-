#include "DR16_Receiver.h"

uint8_t DR16_rxBuff[DR16_DBUS_PACKSIZE+2]; 
DR16_DBUS_DATA_t dr16_data;
rocker_t dr16_rocker_L,dr16_rocker_R;


void DR16_dataProcess(uint8_t *pData){
	if (pData == NULL){
		return;
	}
	/*ҡ�˿���*/
	dr16_data.rc.ch0 = (pData[0] | (pData[1] << 8)) & 0x07FF;
	dr16_data.rc.ch1 = ((pData[1] >> 3) | (pData[2] << 5)) & 0x07FF;
	dr16_data.rc.ch2 = ((pData[2] >> 6) | (pData[3] << 2) | (pData[4] << 10)) & 0x07FF;
	dr16_data.rc.ch3 = ((pData[4] >> 1) | (pData[5] << 7)) & 0x07FF;
  dr16_data.rc.s_left = ((pData[5] >> 4) & 0x000C) >> 2;
	dr16_data.rc.s_right = ((pData[5] >> 4) & 0x0003);
	
	/*PC����*/
	dr16_data.mouse.x = (pData[6]) | (pData[7] << 8);
	dr16_data.mouse.y = (pData[8]) | (pData[9] << 8);
	dr16_data.mouse.z = (pData[10]) | (pData[11] << 8);
	dr16_data.mouse.keyLeft = pData[12];
	dr16_data.mouse.keyRight = pData[13];
	dr16_data.keyBoard.key_code = pData[14]| (pData[15] << 8);

	dr16_data.infoUpdateFrame++;
	
	dr16_data.rc.ch0 -=1024;
	dr16_data.rc.ch1 -=1024;
	dr16_data.rc.ch2 -=1024;
	dr16_data.rc.ch3 -=1024;
	
	if(dr16_data.rc.ch0 <= 20&& dr16_data.rc.ch0 >= -20)
		dr16_data.rc.ch0 = 0;
	if(dr16_data.rc.ch1 <= 20 && dr16_data.rc.ch1 >= -20)
		dr16_data.rc.ch1 = 0;
	if(dr16_data.rc.ch2 <= 20 && dr16_data.rc.ch2 >= -20)
		dr16_data.rc.ch2 = 0;
	if(dr16_data.rc.ch3 <= 20 && dr16_data.rc.ch3 >= -20)
		dr16_data.rc.ch3 = 0;
	
	
	//����X,Y���꣬��ң������Ӧ�ٶȷ���
	Rocker_getData(-dr16_data.rc.ch3, dr16_data.rc.ch2, &dr16_rocker_L);
	Rocker_getData(dr16_data.rc.ch0, dr16_data.rc.ch1, &dr16_rocker_R);
}

void DR16_receiverInit(void){
	USART1_QuickInit(100000);
	USART1_RXDMA_Config((uint32_t)DR16_rxBuff, DR16_DBUS_PACKSIZE+2);
}






