#include "M6020s.h"

M6020s_t M6020s[4];
int M6020_Flga_0 = 0 ;
int M6020_Flga_1 = 0 ;

void M6020_getInfo(CanRxMsg RxMessage,int can_id)
{
	uint32_t StdId;
	StdId = RxMessage.StdId - 0x205;
	if(can_id == 2)
		StdId += 2;
	M6020s[StdId].realAngle = (uint16_t)(RxMessage.Data[0]<<8 | RxMessage.Data[1]);
	M6020s[StdId].reaSpeed = (int16_t)(RxMessage.Data[2]<<8 | RxMessage.Data[3]);
	M6020s[StdId].realCurrent = (int16_t)(RxMessage.Data[4]<<8 | RxMessage.Data[5]);
	M6020s[StdId].realTemperature = (int16_t)(RxMessage.Data[6]);
	if(StdId == 0)
		M6020_Flga_0++;
	if(StdId == 1)
		M6020_Flga_1++;
  M6020s[StdId].infoUpdateFrame++;
	M6020s[StdId].infoUpdateFlag = 1;
	
	if(M6020s[0].realAngle < 4000)
		M6020s[0].totalAngle = M6020s[0].realAngle + 8191;
	else 
		M6020s[0].totalAngle = M6020s[0].realAngle;
}




