#include "GY6050s.h"
#include "M6020s.h"


//#define Cloud_Pitch_Center	0.0f

GY_IMU_t GY_6050[1];
bno055_data_u bno055_data[2];


void GY6050_getCloundInfo(CanRxMsg RxMessage){
	
		memcpy(bno055_data[0].dataBuff, RxMessage.Data, sizeof(uint8_t[8]));
		GY_6050[0].EularDate.Yaw = (float)bno055_data[0].yaw/100.0f;
		GY_6050[0].Gyro.x = bno055_data[0].gyro_x / 16;
		GY_6050[0].EularDate.Pitch = (float)bno055_data[0].pitch/100.0f + 180.0f;
		GY_6050[0].Gyro.z = bno055_data[0].gyro_z / 16;
		GY_6050[0].EularDate.Yaw = (int16_t)(GY_6050[0].EularDate.Yaw / 360 *8191);
    GY_6050[0].EularDate.Pitch = (int16_t)(GY_6050[0].EularDate.Pitch / 360 *8191);
	
		if(GY_6050[0].EularDate.Yaw - GY_6050[0].lastYaw < -4000){
			GY_6050[0].Yaw_turnCount++;
		}	
		if(GY_6050[0].lastYaw - GY_6050[0].EularDate.Yaw  < -4000){
			GY_6050[0].Yaw_turnCount--;
		}
		if(GY_6050[0].EularDate.Pitch - GY_6050[0].lastPitch < -4000){
			GY_6050[0].Pitch_turnCount++;
		}	
		if(GY_6050[0].lastPitch - GY_6050[0].EularDate.Pitch  < -4000){
			GY_6050[0].Pitch_turnCount--;
		}

		GY_6050[0].totalYaw = GY_6050[0].EularDate.Yaw + (8191 * GY_6050[0].Yaw_turnCount);
		GY_6050[0].totalPitch = GY_6050[0].EularDate.Pitch + (8191 * GY_6050[0].Pitch_turnCount);
			
		
		GY_6050[0].lastYaw = GY_6050[0].EularDate.Yaw;
		GY_6050[0].lastPitch = GY_6050[0].EularDate.Pitch;
			
		GY_6050[0].ImuInfoUpdateFrame++;
		GY_6050[0].ImuInfoUpdateFlag = 1;

}	


float Temp_Ramp_angle = 0.0f;
float Real_Ramp_angle = 0.0f;
float Cloud_Pitch_Center = 2600.0f;
int Ramp_Detection(void)
{
	 static int Ramp_Counter = 0;

   if(Cloud_Pitch_Center != M6020s[1].realAngle)
	 {
     Temp_Ramp_angle =(float)((( M6020s[1].realAngle - Cloud_Pitch_Center) - (GY_6050[0].EularDate.Pitch-4000)) /22.75f);
		 if(Temp_Ramp_angle>20)
		 {
		   Ramp_Counter++;
		 }
	 }

	 if(Ramp_Counter > 20)
	 { 
			 Real_Ramp_angle = Temp_Ramp_angle;
	 }
	 if(Temp_Ramp_angle< 20)
	 {
	   Real_Ramp_angle = 0;
	 }
	 
	 return Real_Ramp_angle;
}


