#include "Monitor.h"

static uint32_t lost_err = 0xFFFFFFFF;

/**
	* @brief  ������ֵ�Ƿ�׼ȷ
  * @param	void
  * @retval 0 ׼ȷ 			1 ����
  */
uint8_t LostCounterOverCheck(uint16_t counter,uint16_t len)
{
	return counter>len?0:1;
}


uint32_t GetLostError(uint32_t err)
{
	return lost_err&err;
}



/**
	* @brief  ����豸�Ƿ��֡
  * @param	void
  * @retval 0 �� 			1 ��
  */
uint8_t LostCounterCheck(uint32_t err)
{
	return !(GetLostError(err)&err);
}



