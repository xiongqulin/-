#include "PC_key.h"
#include "UserMath.h"

//������������ʼ��
void Key_Config(Key_t *key)
{
	key->KeyCheckflag = 0;
	key->KeyStatus = 0;
	key->Key_err = 0;
	key->lastKeyStatus = 0;
	key->Out_Key = 0;
}


//��������
int Key_Check_Single(bool Keycheck,Key_t *key)
{
	if(Keycheck == 1) 
	{
		key->KeyStatus++;
		key->KeyCheckflag = 1;
	}
	if(key->KeyCheckflag == 1)
	{
	key->Key_err = key->KeyStatus - key->lastKeyStatus;
	if(key->Key_err == 0)
	{
		key->Out_Key ++;
		key->KeyCheckflag = 0;	
	}
	key->lastKeyStatus = key->KeyStatus;
}
	return key->Out_Key;
}

//��������
int Key_CheckVolageCHeck(bool Keycheck,Key_t *key)
{
	if(Keycheck == 0) 
	{
		key->KeyStatus++;
		key->KeyCheckflag = 1;
	}
	

	if(key->KeyCheckflag == 1)
	{
	key->Key_err = key->KeyStatus - key->lastKeyStatus;
	if(key->Key_err == 0)
	{
		key->Out_Key ++;
		key->KeyStatus = 0;
		key->KeyCheckflag = 0;	
	}
	key->lastKeyStatus = key->KeyStatus;
}
	return key->Out_Key;
}

/*��ϼ�����*/
int Key_Check_Group(bool Keycheck_1,bool Keycheck_2,Key_t *key)
{
	if(Keycheck_1 && Keycheck_2)
	{
		key->KeyStatus++;
		key->KeyCheckflag = 1;
	}
	if(key->KeyCheckflag == 1)
	{
		key->Key_err = key->KeyStatus - key->lastKeyStatus;
		if(key->Key_err == 0)
		{
			key->Out_Key ++;
			key->KeyCheckflag = 0;	
		}
		key->lastKeyStatus = key->KeyStatus;
  }
	return key->Out_Key;
}


void Key_direction_Config(Direction_t *Direction,int16_t Normal_Speed,int16_t Change_Speed,int16_t Speed_Max)
{
	Direction->Change_Speed = Change_Speed;
  Direction->Normal_Speed = Normal_Speed;
	Direction->Out_Speed = 0;
	Direction->Speed_D = 0;
	Direction->Speed_Max = Speed_Max;
	Direction->Change_Speed_Max = abs(Speed_Max - Normal_Speed);
	if(Direction->Normal_Speed < 0)
		Direction->Check = 0;
	else
		Direction ->Check = 1;
}

	
//ǰ�����ҷ��򰴼��ṹ��
/*��shift���٣���Ctrl����*/
int16_t Key_direction(bool Key,bool Shift,bool Cttl,Direction_t *Direction)
 {
	 if(Key)
	 {
		 if(Direction->Check)
		   Direction->Normal_Speed = 2500;
		 else
			 Direction->Normal_Speed = -2500;
		 if(Shift)
		 {
			Direction->Speed_U += Direction->Change_Speed;
			 if(Direction->Speed_U > Direction->Change_Speed_Max)
			 {
				 Direction->Speed_U = Direction->Change_Speed_Max;
			 }
		 }
		else
		{
			Direction->Speed_U -= 2*Direction->Change_Speed;
		  if(Direction->Speed_U < 0)
				Direction->Speed_U = 0;
		}
		if(Cttl)
		{
			Direction->Speed_D += Direction->Change_Speed;
			if(Direction->Speed_D >= abs(Direction->Normal_Speed))
			{
				Direction->Speed_D = abs(Direction->Normal_Speed);
			}
		}
		else
		{
			Direction->Speed_D -= 2*Direction->Change_Speed;
			if(Direction->Speed_D < 0)
			{
				Direction->Speed_D = 0;
			}
		}
		
		
	 }
	 else
	 {
		 if(Direction->Speed_U > 0)
		 {
			 Direction->Speed_U -= 4*Direction->Change_Speed;
		  if(Direction->Speed_U < 0)
				Direction->Speed_U = 0; 
		 }
		 if(Direction->Speed_D > 0)
		 {
			 Direction->Speed_D -= 4*Direction->Change_Speed;
			if(Direction->Speed_D < 0)
			{
				Direction->Speed_D = 0;
			}
		 }
		 if(Direction->Normal_Speed > 0)
		 {
			 Direction->Normal_Speed -= 4*Direction->Change_Speed;;
			 if(Direction->Normal_Speed <= 0)
				 Direction->Normal_Speed = 0;
		 }
		 else
		 {
			 Direction->Normal_Speed += 4*Direction->Change_Speed;;
			 if(Direction->Normal_Speed >= 0)
				 Direction->Normal_Speed = 0;
		 }
	 }
	 if(Direction->Normal_Speed > 0)
	 {
		 Direction->Out_Speed = Direction->Normal_Speed + Direction->Speed_U - Direction->Speed_D;
	 }
	 else
	 {
		 Direction->Out_Speed = Direction->Normal_Speed - Direction->Speed_U + Direction->Speed_D;
	 }
//	 if(Direction->Out_Speed > Direction->Speed_Max)
//		 Direction->Out_Speed = Direction->Speed_Max;
//	 if(Direction->Out_Speed < Direction->Speed_Max)
//		 Direction->Out_Speed = Direction->Speed_Max;
	 
	 return Direction->Out_Speed;	 
}
 


