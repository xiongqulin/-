#include "Driver_Vision.h"
#include "UserMath.h"
#include "bsp_usart.h"
#include "string.h"
#include "Driver_CRC.h"


VisionData_t VisionData;
uint8_t Vision_DataBuff[Vision_BuffSIZE];


float vision_offset_x_l = 0.0f, vision_offset_y_l = 0.0f;
float vision_forecast_coe = 0.00;

const uint8_t VisionSendBuf[3][4] = {'S','1','1','E',//Сװ��
																			'S','1','2','E',//��װ��
																			'S','2','1','E'};//��糵

uint8_t Vision_Diff_Time_Count;
uint16_t Vision_Frame_Count;
																			
uint16_t Vision_Frame;
											
uint8_t vision_frame;
																			
float vision_x_diff, vision_y_diff;
float vision_x_last, vision_y_last;		
																			
/**
	* @brief  �Ӿ����ݴ�������
  * @param	��������
  * @retval None
  */
void VisionDataProcess(u8 *data)
{
	if (data == NULL)
	{
		return;
	}
	
	uint8_t CRCBuffer = Checksum_CRC8(data,12);
	int16_t CRCSenderBuffer = (data[12]-48)*100+(data[13]-48)*10+(data[14]-48);
	
	if((data[15] == 'E') && (CRCBuffer == CRCSenderBuffer))
	{
		VisionData.vision_x = ((data[3] - 48)*100+ (data[4] - 48)*10 + (data[5] - 48)) - 320;
		VisionData.vision_y = ((data[6] - 48)*100+ (data[7] - 48)*10 + (data[8] - 48)) - 240;
		VisionData.vision_depth = (data[9] - 48)*100+ (data[10] - 48)*10 + (data[11] - 48);
		
		if(VisionData.vision_depth != 0)
		{				
			VisionData.vision_diff_x = VisionData.vision_x - VisionData.vision_last_x;
			VisionData.vision_diff_y = VisionData.vision_y - VisionData.vision_last_y;
			vision_offset_y_l = 0.0020*GetVisionDepth()*GetVisionDepth() - 0.8668*GetVisionDepth() + 139.9661;
			
			if(abs(VisionData.vision_diff_x) < 5)			
			{
				vision_offset_x_l = - 20;
				//vision_offset_x = (VisionData.vision_depth/2000.0f) * GetImuGry_Z(GY955) * 6.0f - 20;
			}
			else
			{
				vision_offset_x_l = -20;
			}
			
			VisionData.vision_last_x = VisionData.vision_x;
			VisionData.vision_last_y = VisionData.vision_y;
		}		
		else
		{
			VisionData.vision_diff_x = 0;
			VisionData.vision_diff_y = 0;
			VisionData.vision_last_x = vision_offset_x_l;
			VisionData.vision_last_y = vision_offset_y_l;
		}
				
		Vision_Frame_Count++;
		
		if(Vision_Diff_Time_Count > 200)
		{
			Vision_Frame = Vision_Frame_Count;
			Vision_Diff_Time_Count = 0;
			Vision_Frame_Count = 0;
		}
		
	}
	
	if ((data[1] == '1') && (data[2] == '1'))//����
	{
		VisionData.AimType = AUTOAIM;
	}
	else if ((data[1] == '2') && (data[2] == '1'))//��糵
	{
		VisionData.AimType = BIGWHEEL;
	}
	
	VAL_LIMIT(VisionData.vision_x, -320,320);
	VAL_LIMIT(VisionData.vision_y, -240,240);
	VisionData.infoUpdateFrame++;

}

/**
	* @brief  �Ӿ����Ӧ����
	* @param	
  * @retval None
  */
void VisionDiffCulc(void)
{
	vision_x_diff = VisionData.vision_x - vision_x_last;
	vision_y_diff = VisionData.vision_y - vision_y_last;
	
	vision_x_last = VisionData.vision_x;
	vision_y_last = VisionData.vision_y;
	
}

/**
	* @brief  �Ӿ�ʶ�������л�
	* @param	����
  * @retval None
  */
void VisionModeSwitch(uint8_t Type)
{
	if((Type<4)&&(Type>=0))
	{
		SendVisionData(VisionSendBuf[Type]);	
	}

}



/**
	* @brief  ��ȡ�Ӿ�ʶ������
  * @param	����
  * @retval ����
  */
int16_t GetCoordx(u8 coordx)
{
	if (coordx == VISION_X)
	{
		return VisionData.vision_x;
	}
	else if (coordx == VISION_Y)
	{
		return VisionData.vision_y;
	}
	else
	{
		return 0;
	}
}

/**
	* @brief  ��ȡ�Ӿ�����仯��
  * @param	����
  * @retval �仯��
  */
int16_t GetCorrdxDiff(u8 coordx)
{
	if (coordx == VISION_X)
	{
		return VisionData.vision_diff_x;
	}
	else if (coordx == VISION_Y)
	{
		return VisionData.vision_diff_y;
	}
	else
	{
		return 0;
	}
}


/**
	* @brief  �Ӿ��������ݺ���
  * @param	����
  * @retval None
  */
void SendVisionData(const uint8_t *data)
{
	if(data == NULL)
	{
		return;
	}
	for(int i = 0;i<4;i++)
	{
		USART_sendChar(USART6,data[i]);
	}
	
}

/**
	* @brief  ��ȡ�Ӿ�����
  * @param	void
  * @retval ����
  */
uint8_t GetAimType(void)
{
	return VisionData.AimType;
}


/**
	* @brief  ��ȡ�Ӿ�����
  * @param	void
  * @retval ����
  */
uint16_t GetVisionDepth(void)
{
	return VisionData.vision_depth;
}



/**
	* @brief  �Ӿ����ݸ�λ
  * @param	void
  * @retval None
  */
void VisionReset(void)
{
	VisionData.vision_diff_x = 0.0f;
	VisionData.vision_diff_y = 0.0f;
	VisionData.vision_last_x = 0.0f;
	VisionData.vision_last_y = 0.0f;	
}


void VisionBSP_Init(void){
	USART6_QuickInit(115200);
	USART6_RXDMA_Config((uint32_t)Vision_DataBuff,Vision_BuffSIZE);
}

