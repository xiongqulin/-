#include "M2006s.h"


M2006s_t M2006s[3];
void M2006_getInfo(CanRxMsg RxMessage)
{
	uint32_t StdId;
	StdId = RxMessage.StdId - 0x207;
	if(RxMessage.StdId == 0x204)
		StdId = 2;
	M2006s[StdId].realAngle = (uint16_t)RxMessage.Data[0] << 8 |  RxMessage.Data[1];
	M2006s[StdId].realSpeed = (int16_t)RxMessage.Data[2] << 8 | RxMessage.Data[3];
  M2006s[StdId].realTorque = (int16_t)RxMessage.Data[4] << 8 | RxMessage.Data[5];
	if(M2006s[StdId].realAngle - M2006s[StdId].lastAngle < -6000){
		M2006s[StdId].turnCount++;
	}
	
	else if(M2006s[StdId].lastAngle - M2006s[StdId].realAngle < -6000){
		M2006s[StdId].turnCount--;
	}
	M2006s[StdId].lastAngle = M2006s[StdId].realAngle;
	M2006s[StdId].totalAngle = M2006s[StdId].realAngle + ( M2006s[StdId].turnCount * 8192 );
	
	M2006s[StdId].infoUpdateFrame++;
	M2006s[StdId].infoUpdateFlag = 1;
}




