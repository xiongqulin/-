/**
	|--------------------------------- Copyright --------------------------------|
	|                                                                            |
	|                      (C) Copyright 2019,����ƽͷ��,                         |
	|           1 Xuefu Rd, Huadu Qu, Guangzhou Shi, Guangdong Sheng, China      |
	|                           All Rights Reserved                              |
	|                                                                            |
	|           By(GCU The wold of team | ����������ѧ����ѧԺ������Ұ�Ƕ�)         |
	|                    https://github.com/GCUWildwolfteam                      |
	|----------------------------------------------------------------------------|
	|--FileName    : power_buffer_pool.h                                                
	|--Version     : v1.0                                                            
	|--Author      : ����ƽͷ��                                                       
	|--Date        : 2019-03-24               
	|--Libsupports : 
	|--Description :                                                       
	|--FunctionList                                                       
	|-------1. ....                                                       
	|          <version>:                                                       
	|     <modify staff>:                                                       
	|             <data>:                                                       
	|      <description>:                                                        
	|-------2. ...                                                       
	|-----------------------------declaration of end-----------------------------|
 **/
#ifndef __POWER_H
#define __POWER_H


#include <stdint.h>

typedef struct
{
	uint8_t data_buff;
	float volt;
	float current;
	float power;
	float power_buffer;
}currentMeterStruct;

typedef struct powerBufferPoolStruct
{
	currentMeterStruct* pcurrentMeter_t;	
	float max_p;//���Ĺ��ʵ�λ������
	float max_w;//���Ĺ��ʵ�λ������
	float r_w;//ʵʱ�Ĺ��ʵ�λ������
  float r_p;//ʵʱ�Ĺ��ʵ�λ������
	float current_mapp_coe;//����ӳ��ϵ��
	float high_water_level;
	float low_water_level;
	float mid_water_level;
	float period;//�������ڣ���λ/s
	float high_current_threshold;//A
  float mid_current_threshold;//A
  float low_current_threshold;//A
  float safe_current_threshold;//A
	
	
    float ramp_high_water_level;//4.8;//240.0;
    float ramp_low_water_level ; //2.12;//106.0;
    float ramp_mid_water_level ;  //160.0;		
    float ramp_high_current_threshold ;//����ϵͳ��ĵ�����ֵ9A
    float ramp_mid_current_threshold ;//����ϵͳ��ĵ�����ֵ7A
    float ramp_low_current_threshold ;//����ϵͳ��ĵ�����ֵ7A
    float ramp_safe_current_threshold ;//����ϵͳ��ĵ�����ֵ3.5A	
}powerBufferPoolStruct;


extern powerBufferPoolStruct powerBufferPool_t;

void PowerBufferPoolInit(void);
float OutMapCurrent(float coe,int16_t input);
int16_t CurrentMapOut(float coe,float current);
uint8_t Inject(powerBufferPoolStruct* pbs);
int16_t GetOutlet(powerBufferPoolStruct* pbs,int16_t input);
uint8_t GetPowerPoolState(powerBufferPoolStruct* pbs,float angle);
void SetInPut(powerBufferPoolStruct* pbs,int16_t *input,uint8_t len);

#endif	// __POWER_BUFFER_POOL_H
/*-----------------------------------file of end------------------------------*/



