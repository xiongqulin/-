#ifndef __MONITOR_H
#define __MONITOR_H

#include "stdint.h"

#define LOST_ERROR_RC										(1<<0)		//rc lost 
#define LOST_ERROR_GY955								(1<<1)		//gy955 error
#define LOST_ERROR_LFMOTOR							(1<<2)		//motor3508 error
#define LOST_ERROR_RFMOTOR							(1<<3)		//~
#define LOST_ERROR_LBMOTOR							(1<<4)		//~
#define LOST_ERROR_RBMOTOR							(1<<5)		//~
#define LOST_ERROR_YAWMOTOR							(1<<6)		//motor6623 error
#define LOST_ERROR_PITCHMOTOR						(1<<7)		//~
#define LOST_ERROR_KRELOADMOTOR					(1<<8)		//motor2006 error
#define LOST_ERROR_VISION								(1<<9)		//mpu6050 error


uint8_t LostCounterOverCheck(uint16_t counter,uint16_t len);
uint8_t LostCounterCheck(uint32_t err);

#endif

