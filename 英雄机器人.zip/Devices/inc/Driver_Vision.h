#ifndef _DRIVER_VISION_H
#define _DRIVER_VISION_H

#include "stm32f4xx.h"

#define Vision_BuffSIZE (16+2)		  //�Ӿ����ݻ���������
extern uint8_t Vision_DataBuff[Vision_BuffSIZE];

enum 
{
	AUTOAIM,
	BIGWHEEL,
	VISION_X,
	VISION_Y
};

enum
{
	LITTLE_ARMOR,
	BIG_ARMOR,
	BIG_WHEEL
};


typedef struct
{
	int16_t vision_x;
	int16_t vision_y;
	int16_t vision_depth;//���
	int16_t vision_last_x;
	int16_t vision_last_y;
	int16_t vision_diff_x;
	int16_t vision_diff_y;
	int16_t BuzzCenter_x;
	int16_t BuzzCenter_y;
	uint8_t AimType;//Ŀ������
	uint16_t infoUpdateFrame;//֡��
	uint8_t offLineFlag;
}VisionData_t;

extern VisionData_t VisionData;

extern uint8_t Vision_Diff_Time_Count;
extern uint8_t vision_frame;

extern void VisionDataProcess(u8 *data);
extern int16_t GetCoordx(u8 coordx);
extern uint8_t GetAimType(void);
extern void SendVisionData(const uint8_t *data);
extern int16_t GetCorrdxDiff(u8 coordx);
extern void VisionReset(void);
extern uint16_t GetVisionDepth(void);
extern void VisionModeSwitch(uint8_t Type);
extern void VisionDiffCulc(void);
void VisionBSP_Init(void);

#endif


