#ifndef __DR16_RECEIVER_H
#define __DR16_RECEIVER_H


#include "Rocker.h"
#include <stdbool.h>
#include "bsp_usart.h"

/*��������������*/
#pragma anon_unions

#define DR16_DBUS_PACKSIZE 		18u		//���ջ�����С

#define DR16_ROCKER_MAXVALUE 		660		//ң��ҡ�����ֵ


//���������¶�Ӧֵ
#define DR16_SWITCH_UP			1
#define DR16_SWITCH_MID			3
#define DR16_SWITCH_DOWN		2

#define MOUSEKEY_NONE 	0x00
#define MOUSEKEY_LEFT 	0x01
#define MOUSEKEY_RIGHT 	0x02

/*-------���̼�ֵ Begin------*/
#define KEYBOARD_PRESSED_NONE 	0x0000

#define KEYBOARD_PRESSED_W 		0x0001
#define KEYBOARD_PRESSED_S 		0x0002
#define KEYBOARD_PRESSED_A 		0x0004
#define KEYBOARD_PRESSED_D 		0x0008
#define KEYBOARD_PRESSED_SHIFT 	0x0010
#define KEYBOARD_PRESSED_CTRL 	0x0020
#define KEYBOARD_PRESSED_Q  	0x0040
#define KEYBOARD_PRESSED_E 		0x0080

#define KEYBOARD_PRESSED_R		0x0100
#define KEYBOARD_PRESSED_F		0x0200
#define KEYBOARD_PRESSED_G		0x0400
#define KEYBOARD_PRESSED_Z		0x0800
#define KEYBOARD_PRESSED_X		0x1000
#define KEYBOARD_PRESSED_C		0x2000
#define KEYBOARD_PRESSED_V		0x4000
#define KEYBOARD_PRESSED_B		0x8000
/*-------���̼�ֵ End------*/

#define KEY_FULL_MATCH			0x01
#define KEY_HAVE_MATCH			0x00



typedef struct{
	uint16_t KeyStatus;
	uint16_t lastKeyStatus;
	uint16_t KeyCheckflag;
	uint16_t Out_Key;
	uint16_t Key_err;
}key_t;

typedef struct {
	struct{
		int16_t ch0;
		int16_t ch1;
		int16_t ch2;
		int16_t ch3;

		uint8_t s_left;
		uint8_t s_right;
	}rc;
	
	struct{
		int16_t x;
		int16_t y;
		int16_t z;
	
		uint8_t keyLeft;
		uint8_t keyRight;
		
	}mouse;
	
	
	union {
		uint16_t key_code;
		struct{
			bool press_W:1;
			bool press_S:1;
			bool press_A:1;
			bool press_D:1;
			bool press_Shift:1;
			bool press_Ctrl:1;
			bool press_Q:1;
			bool press_E:1;
			
			bool press_R:1;
			bool press_F:1;
			bool press_G:1;
			bool press_Z:1;
			bool press_X:1;
			bool press_C:1;
			bool press_V:1;
			bool press_B:1;
		};
	}keyBoard;
	
	uint16_t infoUpdateFrame;	//֡��
	uint8_t offLineFlag;		  //�豸���߱�־
}DR16_DBUS_DATA_t;

void Rocker_getData(float posX, float posY, rocker_t *roc);
void DR16_KeyProcess(uint16_t newKeyStatus, key_t *key);
void DR16_dataProcess(uint8_t *pData);
void DR16_receiverInit(void);
extern uint8_t DR16_rxBuff[DR16_DBUS_PACKSIZE+2];
extern DR16_DBUS_DATA_t dr16_data;


extern rocker_t dr16_rocker_L,dr16_rocker_R;
extern rocker_t pcRocker;

#endif /* __DR16_RECEIVER_H */


