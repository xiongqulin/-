#ifndef PC_KEY_H
#define PC_KEY_H

#include <arm_math.h>
#include <stdbool.h>

typedef struct{
	uint16_t KeyStatus;
	uint16_t lastKeyStatus;
	uint16_t KeyCheckflag;
	int Out_Key;
	uint16_t Key_err;
}Key_t;

typedef struct{
	int16_t Out_Speed;                 //����ٶ�
	int16_t Normal_Speed;              //�����ٶ�
  int16_t Change_Speed;              //�仯�ٶ�
	int16_t Change_Speed_Max;          //����ٶ�
	int16_t Speed_Max;                 //����ٶ�
	int16_t Speed_U;                   //���ӵ��ٶ�
	int16_t Speed_D;                   //��С���ٶ�
	int16_t Check;                     //�ж���������
}Direction_t;


void Key_Config(Key_t *key);
int Key_Check_Single(bool Keycheck,Key_t *key);
int Key_Check_Group(bool Keycheck_1,bool Keycheck_2,Key_t *key);
int16_t Key_direction(bool Key,bool Shift,bool Cttl,Direction_t *Direction);
void Key_direction_Config(Direction_t *Direction,int16_t Normal_Speed,int16_t Change_Speed,int16_t Speed_Max);
int Key_CheckVolageCHeck(bool Keycheck,Key_t *key);


#endif



