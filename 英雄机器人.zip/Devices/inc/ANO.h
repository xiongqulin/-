#ifndef _ANO_H 
#define _ANO_H 

#include <stdint.h>


void ANO_Send_Data_V3(int16_t Temp_Target1,int16_t Temp_Now1,int16_t Temp_Target2,int16_t Temp_Now2);
void ANO_GPIO_Init(void);
void ANO_Init(void);


#endif 



