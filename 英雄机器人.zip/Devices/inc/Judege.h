#ifndef __JUDEGE_H
#define __JUDEGE_H

#include "stm32f4xx.h"

#define JudgeBufferLength       200	

#define JudgeFrameLength_001      12
#define JudgeFrameLength_002      10
#define JudgeFrameLength_003      11
#define JudgeFrameLength_101      13
#define JudgeFrameLength_102      12
#define JudgeFrameLength_103      11
#define JudgeFrameLength_201      24
#define JudgeFrameLength_202      23
#define JudgeFrameLength_203    	25
#define JudgeFrameLength_204    	10
#define JudgeFrameLength_205    	12
#define JudgeFrameLength_206    	10
#define JudgeFrameLength_207    	15
#define JudgeFrameLength_301    	22

#define JudgeFrameHeader        0xA5        //֡ͷ
#define JudageDataOffset		0x07		//����ƫ����


#define Judge_BuffSIZE 	200u			//����ϵͳ����������
#define JUDGE_PACKSIZE 		    180u		//����ϵͳ����С

//����״̬����
typedef __packed struct
{
uint8_t game_type : 4;
uint8_t game_progress : 4;
uint16_t stage_remain_time;
}ext_game_state_t;

//�����������
typedef __packed struct
{
uint8_t winner;
} ext_game_result_t;


//�����˴������
typedef __packed struct
{
uint16_t robot_legion;
}ext_game_robot_survivors_t;


//�����¼�����
typedef __packed struct
{
uint32_t event_type;
}ext_event_data_t;

//����վ������ʶ
typedef __packed struct
{
uint8_t supply_projectile_id;
uint8_t supply_robot_id;
uint8_t supply_projectile_step;
uint8_t supply_projectile_num;
}ext_supply_projectile_action_t;

//����վԤԼ�ӵ�
typedef __packed struct
{
uint8_t supply_projectile_id;
uint8_t supply_robot_id;
uint8_t supply_num;
} ext_supply_projectile_booking_t;

//����������״̬
typedef __packed struct
{
uint8_t robot_id;
uint8_t robot_level;
uint16_t remain_HP;
uint16_t max_HP;
uint16_t shooter_heat0_cooling_rate;
uint16_t shooter_heat0_cooling_limit;
uint16_t shooter_heat1_cooling_rate;
uint16_t shooter_heat1_cooling_limit;
uint8_t mains_power_gimbal_output : 1;
uint8_t mains_power_chassis_output : 1;
uint8_t mains_power_shooter_output : 1;
} ext_game_robot_state_t;

//ʵʱ������������
typedef __packed struct
{
uint16_t chassis_volt;
uint16_t chassis_current;
float chassis_power;
uint16_t chassis_power_buffer;
uint16_t shooter_heat0;
uint16_t shooter_heat1;
} ext_power_heat_data_t;

//������λ��
typedef __packed struct
{
float x;
float y;
float z;
float yaw;
}ext_game_robot_pos_t;

//����������
typedef __packed struct
{
uint8_t power_rune_buff;
}ext_buff_musk_t;

//���л���������״̬
typedef __packed struct
{
uint8_t energy_point;
uint8_t attack_time;
}aerial_robot_energy_t;

//�˺�����
typedef __packed struct
{
uint8_t armor_id : 4;
uint8_t hurt_type : 4;
}ext_robot_hurt_t;


//ʵʱ�����Ϣ
typedef __packed struct
{
uint8_t bullet_type;      //�ӵ�����
uint8_t bullet_freq;      //��Ƶ
float bullet_speed;       //����ٶȣ����ƴ�С�������̣�
}ext_shoot_data_t;


typedef __packed struct
{
		float data1;
		float data2;
		float data3;
		uint8_t mask;
}extShowData_t;

typedef __packed struct
{
	uint8_t data[11];
} robot_interactive_data_t;

typedef enum 
{
	Power_Normal,
	OverPower_Little,
	OverPower_Many
}ChassPowerStatus_e;	

extern ChassPowerStatus_e ChassPowerStatus;
extern ext_power_heat_data_t ext_power_heat_data;	
extern ext_game_robot_state_t ext_game_robot_state;	
extern ext_shoot_data_t ext_shoot_data;
extern ext_event_data_t ext_event_data;
extern ext_game_robot_state_t ext_game_robot_state;
extern uint8_t Judge_rxBuff[JUDGE_PACKSIZE];

unsigned char Get_CRC8_Check_Sum(unsigned char *pchMessage,unsigned int dwLength,unsigned char ucCRC8);
unsigned int Verify_CRC8_Check_Sum(unsigned char *pchMessage, unsigned int dwLength);
void Append_CRC8_Check_Sum(unsigned char *pchMessage, unsigned int dwLength);
uint16_t Get_CRC16_Check_Sum(uint8_t *pchMessage,uint32_t dwLength,uint16_t wCRC);
uint32_t Verify_CRC16_Check_Sum(uint8_t *pchMessage, uint32_t dwLength);
//void small_shoot_deal(void);


void Judge_Init(void);
void JudgeInfo_Process(uint8_t *JudgeInfo, uint16_t length);
void *datacpy(void *memTo, const void *memFrom, unsigned int size);

#endif

